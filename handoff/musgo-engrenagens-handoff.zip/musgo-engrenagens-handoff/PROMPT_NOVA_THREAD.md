# Prompt para a nova conversa

Cole o texto abaixo no início da nova thread (com este material já no repositório novo).

---

Vamos dar continuidade ao jogo **Musgo & Engrenagens**, um cozy 2,5D isométrico para celular em pé (9:16),
mistura de Stardew Valley, Factorio e Zelda: The Minish Cap, com predominância de automação.

Já existe um protótipo completo em um único HTML (`jogo/index.html`). Agora vamos **portar para Godot 4**,
desenvolvendo no Windows, com esta stack:

- Engine: Godot 4 (versão estável atual), GDScript
- Pixel art e animação: Aseprite + addon Aseprite Wizard
- Diálogos: Dialogic 2
- Câmera: Phantom Camera
- IA dos inimigos: LimboAI
- Testes: GUT
- Efeitos sonoros: jsfxr ou ChipTone

Antes de escrever código, leia nesta ordem:

1. `LEIAME.md` e `CLAUDE.md`
2. `docs/03_stack_godot.md` e `docs/04_plano_de_porte.md`
3. `docs/01_design_do_jogo.md` e `docs/02_arquitetura_do_prototipo.md`
4. `dados/` (tabelas do jogo) e `arte/indice.json` (sprites exportados)

Depois:

1. Confirme comigo as decisões em aberto de `docs/04` (principalmente a perspectiva/arte de `docs/05`).
2. Execute o **Marco M0**: criar o projeto Godot com a configuração de pixel art em retrato, a estrutura de
   pastas proposta, importar `dados/` e `arte/`, deixar o GUT rodando com um primeiro teste e me dizer
   exatamente o que preciso instalar ou clicar no editor (addons, modelos de exportação).
3. Siga os marcos na ordem sugerida (M1 → M3 → M2 → M4…), sempre deixando algo jogável e testado ao fim de cada um.

Preferências: respostas objetivas, em português; diga com clareza o que foi testado e o que não foi.
