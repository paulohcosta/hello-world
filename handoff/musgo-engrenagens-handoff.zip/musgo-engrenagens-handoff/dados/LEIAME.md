# dados/

Exportado de `jogo/index.html` por `ferramentas/exportar_dados.js`. Chaves e nomes iguais aos do código.

| Arquivo | Conteúdo |
|---|---|
| `itens.json` | `id → {n: nome, v: valor de venda, fuel: s de queima, food: meias-vidas curadas, seed, place, ic: [forma, paleta]}` |
| `construcoes.json` | `id → {n, d: descrição ({bolt} = ícone de energia), pw: consumo, gen: geração, r: raio, dirArrow, flat, tall}` |
| `receitas.json` | `id → {out: [item, qtd], in: {item: qtd}, t: s, by: m montadora / c cozinha / f fornalha / h só à mão, tier: etapa mínima}` |
| `fundicao.json` | minério → produto da fornalha |
| `plantacoes.json` | `id → {n, t: s para crescer, y: [mín, máx] colhido, fav: estação favorita 0–3}` |
| `etapas.json` | As 6 etapas: `{n, req, coins, gift, un: o que libera, txt: fala do Pip}` |
| `loja.json` | Itens à venda (`id, p`) e melhorias (`up, p: [preços por nível]`), com `tier` mínimo |
| `tesouros.json` | Conteúdo dos 8 baús |
| `criaturas.json` | `stats` (hp, dano, velocidade, raio), quadros por animação, âncoras |
| `heroi.json` | Animações (nº de quadros), ações (`[animação, duração, impacto, usa ferramenta]`), aparências |
| `paletas.json` | Paletas por estação e das máquinas |
| `musica.json` | BPM, escala e acordes dos três modos |
| `construcoes_sprites.json` | Nº de quadros, se é direcional e âncora de cada construção |
| `constantes.json` | Tamanhos de tile, mapa, direções, dias por estação… |
| `terrenos.json` | Enum de terreno e minério → item |
| `mapa.json` | Mapa inicial 80×80: `terreno[y][x]`, `altura_niveis[y][x]`, `objetos`, `entidades_fixas`, posição do jogador |
| `estado_inicial.json` | Estado `G` de um jogo novo |
