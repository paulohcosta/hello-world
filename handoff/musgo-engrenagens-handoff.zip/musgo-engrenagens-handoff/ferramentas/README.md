# Ferramentas do protótipo

Scripts Node.js + Playwright (Chromium headless) usados para testar e fotografar `jogo/index.html`,
e exportadores que extraem dados e arte para reuso.

## Instalação (Windows, PowerShell)

```powershell
cd ferramentas
npm install
npx playwright install chromium
```

Requer Node.js 18 ou mais novo. As saídas (PNG) vão para `ferramentas/saida/`.
Para apontar para outro HTML: `$env:JOGO_HTML="C:\caminho\index.html"`.

## Exportadores

| Script | O que faz |
|---|---|
| `exportar_dados.js` | Grava `dados/*.json`: itens, construções, receitas, etapas, plantações, loja, criaturas, paletas, mapa inicial, estado inicial |
| `exportar_arte.js` | Grava `arte/**/*.png` (ícones, terreno, árvores, objetos, máquinas, personagens, criaturas, interface) e `arte/indice.json` |

`npm run exportar` roda os dois.

## Testes (`testes/`)

| Script | Verifica |
|---|---|
| `soak.js` | 40 mil passos de simulação com ações aleatórias; imprime `errs: []` se não houve erro |
| `fabrica.js` | Cadeia broca → esteira → fornalha → garra → baú, energia, montadora |
| `entrada_toque.js` | Entrada real por toque: direcional, tocar em árvore, criar e colocar construção |
| `progressao.js` | As 6 etapas, ponte, portão, chefe, final e save/load |
| `gestos_fazenda.js` | Arrastar esteiras, modo desmontar, escadas/portão, plantar e colher |
| `cenario.js` | Cortar capim, placa, poço, objetos de cenário após save/load |
| `audio_desempenho.js` | Contexto de áudio ativo, música tocando, fps e tempos de simulação/desenho |

Os testes imprimem o estado observado no console; não usam um framework de asserções. Linhas começando com
`ERR` ou `LOG` indicam erro de página. `npm run testes` roda todos, menos o soak (`npm run soak`).

## Capturas (`capturas/`)

| Script | Gera |
|---|---|
| `ui_telas.js` | Título, HUD, diálogo, abas da mochila, loja, casa, ponte, Relógio, ajuda (`saida/ui/`) |
| `ui_maquinas.js` | Painéis de cada máquina, HUD à noite com barra do chefe |
| `ui_tamanhos.js` | Interface em 360×640 e em desktop |
| `ui_titulo.js`, `ui_icones.js` | Título com jogo salvo; folha de ícones |
| `regioes.js`, `regioes2.js`, `estacoes.js` | Regiões do mapa e as quatro estações (`node capturas/estacoes.js 0,1,2,3`) |
| `noite.js`, `npcs.js`, `combate.js` | Noite com luzes, NPCs e diálogos, combate |
| `fabrica_vitrine.js`, `vitrine_maquinas.js` | Fábrica montada e vitrine de todas as máquinas (`night` como argumento para a versão noturna) |
| `filme_heroi.js`, `filme_criaturas.js` | Tiras de quadros das animações (argumento `a`, `b`, `c`… escolhe a cena) |
| `folha_heroi.js`, `folha_criaturas.js` | Folhas de sprites ampliadas |

Todos os testes e scripts de captura foram reexecutados a partir desta pasta no estado final, sem erros de
página. As imagens em `capturas/` (na raiz do pacote) vieram dessas execuções.

## Como os scripts conversam com o jogo

`lib.js` abre o HTML num contexto de celular (390×844, toque) e devolve `{b, p}` (navegador e página).
Como o jogo declara tudo no escopo global, os testes usam `p.evaluate(() => …)` para ler e alterar o estado
(`G`, `ents`, `give()`, `placeAt()`, `openBag()`…) e `p.tap()` / `p.touchscreen` para entrada real.
