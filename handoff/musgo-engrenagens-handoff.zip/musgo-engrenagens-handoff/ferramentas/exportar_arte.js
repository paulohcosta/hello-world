// Exporta toda a arte procedural do protótipo como PNG em ../arte/ (+ arte/indice.json com tamanhos de quadro).
// A arte é desenhada por código dentro do index.html; este script só lê os canvases já gerados.
// Uso: node exportar_arte.js
const { start, ROOT } = require('./lib.js');
const fs = require('fs'), path = require('path');
(async () => {
  const { b, p } = await start({});
  const res = await p.evaluate(() => {
    const out = {}, meta = {};
    const isC = v => v instanceof HTMLCanvasElement;
    const put = (name, c, m) => { out[name] = c.toDataURL(); meta[name] = Object.assign({ w: c.width, h: c.height }, m || {}) };
    const strip = arr => { const w = Math.max(...arr.map(c => c.width)), h = Math.max(...arr.map(c => c.height)); const [c, g] = mk(w * arr.length, h); arr.forEach((a, i) => g.drawImage(a, i * w, 0)); return { c, m: { quadro_w: w, quadro_h: h, quadros: arr.length } } };
    const putStrip = (name, arr, m) => { const s = strip(arr); put(name, s.c, Object.assign(s.m, m || {})) };
    const walk = (v, name) => {
      if (!v) return; if (isC(v)) { put(name + '.png', v); return }
      if (Array.isArray(v)) { const cs = v.filter(isC); if (cs.length === v.length && cs.length > 1) { putStrip(name + '_tira.png', cs); return } v.forEach((x, i) => walk(x, name + '_' + i)); return }
      if (v instanceof Map) { for (const [k, x] of v) walk(x, name + '_' + String(k).replace(/\W+/g, '-')); return }
      if (typeof v === 'object') for (const k in v) walk(v[k], name + '_' + k);
    };
    const SEA = ['primavera', 'verao', 'outono', 'inverno'];
    // ---- ícones (10x10) ----
    for (const k in ICON) put('icones/' + k + '.png', ICON[k]);
    { const ks = Object.keys(ICON).filter(k => ICON[k].width === 10 && ICON[k].height === 10), cols = 16, [c, g] = mk(cols * 10, Math.ceil(ks.length / cols) * 10), idxm = {};
      ks.forEach((k, i) => { g.drawImage(ICON[k], (i % cols) * 10, ((i / cols) | 0) * 10); idxm[k] = [(i % cols) * 10, ((i / cols) | 0) * 10] }); put('icones/_atlas_10x10.png', c, { celula: 10, posicoes: idxm }) }
    // ---- terreno por estação ----
    const TN = Object.fromEntries(Object.entries(T).map(([n, v]) => [v, n.toLowerCase()]));
    for (let s = 0; s < 4; s++) {
      for (const t in TS[s]) { const arr = TS[s][t]; if (Array.isArray(arr) && arr.length) putStrip('terreno/' + SEA[s] + '/' + (TN[t] || String(t).toLowerCase()) + '_tira.png', arr.filter(isC)) }
      walk(EDGE[s], 'terreno/' + SEA[s] + '/borda'); walk(WATER[s], 'terreno/' + SEA[s] + '/agua'); walk(DEC[s], 'enfeites/' + SEA[s] + '/dec');
    }
    walk(FOAM, 'terreno/comum/espuma'); walk(WETS, 'terreno/comum/molhado'); walk(AOE, 'terreno/comum/alcance'); walk(BANK, 'terreno/comum/margem'); walk(RAIL, 'terreno/comum/corrimao');
    if (typeof STAIR !== 'undefined' && STAIR) walk(STAIR, 'terreno/comum/escada'); walk(ARROW, 'terreno/comum/seta'); walk(HILITE, 'terreno/comum/destaque'); walk(SHADOW, 'terreno/comum/sombra');
    // ---- objetos naturais e ruínas ----
    for (const k in OBJ) if (typeof OBJ[k] !== 'function') walk(OBJ[k], 'objetos/' + k);
    // ---- árvores: estação x tipo x subtipo x tamanho, 3 quadros de balanço ----
    const TK = ['folhosa', 'pinheiro', 'cerejeira', 'cristal'];
    for (let s = 0; s < 4; s++) for (let k = 0; k < 4; k++) for (let sub = 0; sub < (k === 0 ? 3 : 1); sub++) for (let sz = 0; sz < 3; sz++) {
      try { putStrip('arvores/' + SEA[s] + '/' + TK[k] + (k === 0 ? '_v' + sub : '') + '_t' + sz + '_tira.png', [0, 1, 2].map(f => treeSprite(s, k, sub, sz, f, 0)), { ancora: [TA.x, TA.y] }) } catch (e) { }
    }
    // ---- máquinas e construções ----
    for (const k in SPB) { const sp = SPB[k]; putStrip('maquinas/' + k + '_tira.png', sp.f, { ax: sp.ax, ay: sp.ay });
      if (sp.fd) sp.fd.forEach((fr, d) => putStrip('maquinas/' + k + '_dir' + d + '_tira.png', fr, { ax: sp.ax, ay: sp.ay, dir: 'NLSO'[d] })) }
    BELT.forEach((sh, d) => sh.forEach((fr, s) => putStrip('maquinas/esteira_dir' + d + '_forma' + s + '_tira.png', fr, { dir: 'NLSO'[d], forma: ['reta', 'curva_esq', 'curva_dir'][s] })));
    for (let s = 0; s < 4; s++) for (let st = 0; st <= STAGES.length; st++) put('relogio/' + SEA[s] + '_etapa' + st + '.png', hubSprite(s, st));
    // ---- personagens (64x64, âncora HA) ----
    const npcAn = ['idle', 'blink', 'walk', 'wave'];
    for (const lk in LOOKS) for (const an in HANIM) { if (lk !== 'hero' && !npcAn.includes(an)) continue;
      for (const view of [0, 1]) { const vs = lk === 'hero' && (an === 'slashA' || an === 'slashB') ? [0, 1, 2, 3, 4] : [0];
        for (const v of vs) { try { const fr = []; for (let f = 0; f < HANIM[an].n; f++) fr.push(charFrame(lk, an, f, view, v).c);
          putStrip('personagens/' + lk + '/' + an + (view ? '_costas' : '_frente') + (v ? '_espada' + v : '') + '_tira.png', fr, { ancora: [HA.x, HA.y], nota: 'frente = direções S e L (L espelhado); costas = O e N (N espelhado)' }) } catch (e) { } } } }
    walk(CH, 'personagens/extras');
    // ---- criaturas ----
    for (const k in MOBN) for (const an in MOBN[k]) for (const v of [0, 1]) { try { const fr = []; for (let f = 0; f < MOBN[k][an]; f++) fr.push(mobSprite(k, an, f, v).c);
      putStrip('criaturas/' + k + '/' + an + (v ? '_furia' : '') + '_tira.png', fr, { ancora: [MA[k][2], MA[k][3]] }) } catch (e) { } }
    // ---- ferramentas (pixels soltos; giradas por amostragem no jogo) ----
    for (const k in TOOLS) { const t = TOOLS[k], [c, g] = mk(t.w, t.h); for (let i = 0; i < t.px.length; i++) if (t.px[i]) P(g, i % t.w, (i / t.w) | 0, t.px[i]); put('ferramentas/' + k + '.png', c, { pega: [t.gx, t.gy] }) }
    // ---- interface: molduras 9 fatias, padrões, botões, logotipo ----
    const rs = document.documentElement.style;
    for (let i = 0; i < rs.length; i++) { const n = rs[i]; if (!n.startsWith('--')) continue; const m = /url\("?(data:[^")]+)"?\)/.exec(rs.getPropertyValue(n)); if (m) { out['interface/' + n.slice(2) + '.png'] = m[1]; meta['interface/' + n.slice(2) + '.png'] = { css_var: n } } }
    out['interface/logotipo.png'] = $('#logoImg').src; meta['interface/logotipo.png'] = {};
    for (const k in PORT) { out['interface/retrato_' + k + '.png'] = PORT[k]; meta['interface/retrato_' + k + '.png'] = {} }
    return { out, meta };
  });
  const dir = path.join(ROOT, 'arte'); let n = 0;
  for (const name in res.out) { const f = path.join(dir, name); fs.mkdirSync(path.dirname(f), { recursive: true }); fs.writeFileSync(f, Buffer.from(res.out[name].split(',')[1], 'base64')); n++ }
  fs.writeFileSync(path.join(dir, 'indice.json'), JSON.stringify(res.meta, null, 1));
  console.log(n + ' imagens exportadas para arte/');
  await b.close();
})();
