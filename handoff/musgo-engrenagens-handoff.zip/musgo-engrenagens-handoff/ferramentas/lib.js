// Utilitário comum dos testes e capturas (Playwright + Chromium).
// - Abre jogo/index.html (ou o arquivo indicado em JOGO_HTML) num contexto de celular.
// - Todas as saídas (PNG, logs) vão para ferramentas/saida/.
const { chromium } = require('playwright');
const path = require('path'), fs = require('fs'), { pathToFileURL } = require('url');
const ROOT = path.resolve(__dirname, '..');
const GAME = process.env.JOGO_HTML ? path.resolve(process.env.JOGO_HTML) : path.join(ROOT, 'jogo', 'index.html');
const OUT = path.join(__dirname, 'saida');
for (const d of ['', 'ui']) fs.mkdirSync(path.join(OUT, d), { recursive: true });
process.chdir(OUT);
exports.ROOT = ROOT; exports.OUT = OUT; exports.GAME_URL = pathToFileURL(GAME).href;
// start({w,h,dsf,title}) -> {b: browser, p: page}
//   title:1  fica na tela de título; sem isso, começa um jogo novo e fecha o diálogo inicial.
exports.start = async (opts = {}) => {
  const b = await chromium.launch();
  const ctx = await b.newContext({ viewport: { width: opts.w || 390, height: opts.h || 844 }, deviceScaleFactor: opts.dsf || 1, hasTouch: true, isMobile: true });
  const p = await ctx.newPage();
  p.on('console', m => { if (m.type() === 'error') console.log('LOG', m.text()) });
  p.on('pageerror', e => console.log('ERR', e.message, (e.stack || '').split('\n').slice(0, 5).join(' | ')));
  await p.goto(exports.GAME_URL);
  await p.waitForTimeout(600);
  if (!opts.title) {
    await p.tap('#tNew'); await p.waitForTimeout(1500);
    await p.evaluate(() => { DQ = []; dlgShow(); });
  }
  return { b, p };
};
