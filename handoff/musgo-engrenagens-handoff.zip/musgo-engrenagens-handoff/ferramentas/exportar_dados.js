// Exporta as tabelas de dados e o mapa inicial do protótipo para ../dados/*.json
// Uso: node exportar_dados.js
const { start, ROOT } = require('./lib.js');
const fs = require('fs'), path = require('path');
(async () => {
  const { b, p } = await start({});
  const data = await p.evaluate(() => {
    const plain = v => JSON.parse(JSON.stringify(v));           // descarta funções
    const o = {};
    o.constantes = { TW, TH, HZ, MW, MH, DIRS, DAYS_PER_SEASON, SEASON_N, GAP, PR, SAVEKEY, RUIN, BRIDGE_COST, sim_hz: 30,
      nota: 'TW/TH = tamanho do losango do tile em px; HZ = px por nível de altura; MW/MH = mapa; DIRS = N,L,S,O; GAP = espaçamento mínimo entre itens na esteira; PR = raio do jogador (tiles)' };
    o.terrenos = { T, ORE, nota: 'T = enum de terreno; ORE = terreno -> item extraído' };
    o.itens = plain(ITEMS);
    o.construcoes = plain(BLD);
    o.receitas = plain(REC);
    o.fundicao = plain(SMELT);
    o.plantacoes = plain(CROPS);
    o.etapas = plain(STAGES);
    o.loja = plain(SHOP);
    o.tesouros = plain(TREASURE);
    o.criaturas = { stats: plain(MOBD), frames_por_animacao: plain(MOBN), ancoras_sprite: plain(MA) };
    o.heroi = { animacoes: Object.fromEntries(Object.keys(HANIM).map(k => [k, { frames: HANIM[k].n }])), acoes: plain(ACTS), ancora_sprite: plain(HA), aparencias: plain(LOOKS) };
    o.paletas = { estacoes: plain(SPAL), maquinas: plain(MC), contorno: OUT };
    o.musica = plain(MODES);
    o.construcoes_sprites = Object.fromEntries(Object.keys(SPB).map(k => [k, { frames: SPB[k].f.length, direcional: !!SPB[k].fd, ax: SPB[k].ax, ay: SPB[k].ay }]));
    // mapa inicial (jogo novo)
    const rows = a => { const r = []; for (let y = 0; y < MH; y++) r.push(Array.from(a.slice(y * MW, (y + 1) * MW))); return r };
    const objs = []; for (let i = 0; i < obj.length; i++) if (obj[i]) objs.push(Object.assign({ x: i % MW, y: (i / MW) | 0 }, plain(obj[i])));
    o.mapa = { largura: MW, altura: MH, semente: G.seed, terreno: rows(terr), altura_niveis: rows(hgt), objetos: objs,
      entidades_fixas: ents.map(e => ({ k: e.k, x: e.x, y: e.y, d: e.d, fixed: !!e.fixed })), jogador: { x: G.p.x, y: G.p.y },
      nota: 'terreno[y][x] usa o enum T; altura_niveis = 0/1 (platôs); objetos = árvores, pedras, arbustos, ruínas, NPCs, baús' };
    o.estado_inicial = plain(Object.assign({}, G, { p: G.p }));
    return o;
  });
  const dir = path.join(ROOT, 'dados'); fs.mkdirSync(dir, { recursive: true });
  for (const k in data) { fs.writeFileSync(path.join(dir, k + '.json'), JSON.stringify(data[k], null, k === 'mapa' ? 0 : 1)); console.log('dados/' + k + '.json'); }
  await b.close();
})();
