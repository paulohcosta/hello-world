const {start}=require('../lib.js');
(async()=>{const {b,p}=await start({dsf:2,title:1});
  await p.waitForTimeout(1500);await p.screenshot({path:'x_title.png'});
  await p.tap('#tNew');await p.waitForTimeout(1600);await p.evaluate(()=>{DQ=[];dlgShow()});
  // cut tall grass with sword: find nearest tall grass tile, stand next to it, slash
  const r=await p.evaluate(()=>{let best=null,bd=99;for(let y=30;y<52;y++)for(let x=30;x<52;x++){const i=idx(x,y);if(dec[i]===2&&!obj[i]&&!ent[i]&&!solidAt(x,y-1)){const d=Math.hypot(x-G.p.x,y-G.p.y);if(d<bd){bd=d;best=[x,y]}}}
    const[x,y]=best;G.p.x=x+.5;G.p.y=y-.4;G.p.dir=2;pressB();return best});
  await p.waitForTimeout(700);
  console.log(r,await p.evaluate(([x,y])=>({cut:decCut.has(idx(x,y)),drops:drops.length,parts:parts.length}),r));
  // sign and well
  await p.evaluate(()=>{G.p.x=41.5;G.p.y=46.6;G.p.dir=0;G.p.cool=0;G.p.act=null;pressA()});await p.waitForTimeout(500);
  console.log(await p.evaluate(()=>document.querySelector('#toasts').textContent.slice(0,60)));
  await p.evaluate(()=>{G.p.hp=3;G.p.x=33.5;G.p.y=40.6;G.p.dir=0;G.p.cool=0;G.p.act=null;pressA()});await p.waitForTimeout(600);
  console.log(await p.evaluate(()=>({hp:G.p.hp,t:document.querySelector('#toasts').textContent.slice(-40)})));
  await p.evaluate(()=>{G.p.x=40.5;G.p.y=44.2;G.time=7*60});await p.waitForTimeout(600);
  await p.screenshot({path:'x_phone.png'});
  // save / load roundtrip keeps props
  await p.evaluate(()=>saveGame());await p.reload();await p.waitForTimeout(700);await p.tap('#tCont');await p.waitForTimeout(1500);
  console.log(await p.evaluate(()=>({well:!!obj[idx(33,39)],sign:obj[idx(41,45)]&&obj[idx(41,45)].k,braz:obj[idx(31,7)]&&obj[idx(31,7)].k,dec:dec.reduce((a,b)=>a+(b?1:0),0)})));
  await b.close();})();
