const {start}=require('../lib.js');
(async()=>{const {b,p}=await start({dsf:2});
  const shot=async(n)=>{await p.waitForTimeout(400);await p.screenshot({path:n+'.png'})};
  const scr=(x,y)=>p.evaluate(([x,y])=>{const r=cv.getBoundingClientRect();return {sx:r.left+((x-y)*16+VW/2-cam.x)*SC,sy:r.top+((x+y)*8+VH/2-cam.y-hgt[idx(Math.floor(x),Math.floor(y))]*HZ)*SC}},[x,y]);
  // belt drag test
  await p.evaluate(()=>{G.stage=3;give('esteira',20);give('garra',3);for(let y=44;y<50;y++)for(let x=36;x<46;x++)obj[idx(x,y)]=null;});
  await p.click('.slot[data-id="esteira"]');
  const a=await scr(37.5,46.5),c=await scr(42.5,46.5),d=await scr(42.5,48.5);
  await p.mouse.move(a.sx,a.sy);await p.mouse.down();await p.mouse.move(c.sx,c.sy,{steps:12});await p.mouse.move(d.sx,d.sy,{steps:6});await p.mouse.up();
  console.log(await p.evaluate(()=>{const o=[];for(let x=37;x<=42;x++){const e=entAt(x,46);o.push(e?e.k[0]+e.d:'-')}o.push('|');for(let y=47;y<=48;y++){const e=entAt(42,y);o.push(e?e.k[0]+e.d:'-')}return o.join(' ')+' left:'+have('esteira')}));
  // tap existing belt rotates
  await p.mouse.click(a.sx,a.sy);
  console.log('rot',await p.evaluate(()=>entAt(37,46).d));
  // delete mode drag
  await p.click('.slot[data-id="__del"]');
  await p.mouse.move(a.sx,a.sy);await p.mouse.down();await p.mouse.move(c.sx,c.sy,{steps:12});await p.mouse.up();
  console.log('after del',await p.evaluate(()=>{const o=[];for(let x=37;x<=42;x++){const e=entAt(x,46);o.push(e?e.k[0]+e.d:'-')}return o.join(' ')+' have:'+have('esteira')+' mode:'+G.mode}));
  await p.click('.slot[data-id="__del"]');
  // stairs + gate via joystick along iso N
  await p.evaluate(()=>{give('chave',1);G.p.x=40.5;G.p.y=23.5;});
  const joy=await p.$('#joy');const bb=await joy.boundingBox();const cx=bb.x+bb.width/2,cy=bb.y+bb.height/2;
  await p.mouse.move(cx,cy);await p.mouse.down();await p.mouse.move(cx+36,cy-18,{steps:3});await p.waitForTimeout(1500);await p.mouse.up();
  console.log('stairs',await p.evaluate(()=>({x:G.p.x.toFixed(2),y:G.p.y.toFixed(2),z:G.p.z.toFixed(2),dir:G.p.dir,t:findTarget()})));
  await shot('g_gate');
  await p.click('#btnA');await p.waitForTimeout(300);
  console.log(await p.evaluate(()=>({gate:G.flags.gate,obj:obj[idx(40,19)]})));
  // farm + harvester view
  await p.evaluate(()=>{G.p.x=44.5;G.p.y=47.5;G.p.z=0;for(let y=44;y<50;y++)for(let x=36;x<46;x++){obj[idx(x,y)]=null;}give('sem_nabo',9);give('sem_trigo',9);give('sem_abobora',6);give('sem_baga',6);give('colhedora',1);give('catavento',1);give('aspersor',2);give('bau',1);
    const ks=['sem_nabo','sem_trigo','sem_abobora','sem_baga'];for(let y=0;y<4;y++)for(let x=0;x<5;x++){plantAt(ks[y],38+x,44+y);const c=crops.get(idx(38+x,44+y));if(c){c.g=[.1,.4,.7,1,1][x];c.wet=x%2?200:0}}
    placeAt('colhedora',43,45,1);placeAt('catavento',44,43,0);placeAt('bau',44,45,0);placeAt('aspersor',37,45,0);});
  await p.waitForTimeout(4000);
  await shot('g_farm');
  console.log(await p.evaluate(()=>({chest:entAt(44,45).inv,harv:entAt(43,45).inv})));
  await p.click('#bagBtn');await p.click('[data-tab="3"]');await shot('g_map');
  await p.click('[data-tab="0"]');await shot('g_items');
  await b.close();})();
