const {start}=require('../lib.js');
(async()=>{const {b,p}=await start({dsf:2});
  // audio: all sfx + music
  const r=await p.evaluate(async()=>{audioInit();const names=['step','chop','fall','mine','swing','hit','hurt','die','pick','coin','place','plant','pop','water','eat','craft','ui','talk','no','bite','charge','slam','sleep','fanfare','fanfare2'];for(const n of names){sfxLast[n]=0;sfx(n)}return {ac:!!AC,state:AC&&AC.state}});
  console.log(r);
  await p.waitForTimeout(3000);
  console.log(await p.evaluate(()=>({mStep,nextNote:nextNote.toFixed(2),t:AC.currentTime.toFixed(2)})));
  // perf: big factory
  const perf=await p.evaluate(async()=>{G.stage=5;for(let y=30;y<56;y++)for(let x=28;x<54;x++){const i=idx(x,y);if(!ent[i]){obj[i]=null}}
    give('esteira',900);give('garra',100);give('bau',20);
    let n=0;for(let y=44;y<56;y++)for(let x=28;x<54;x++){if(placeAt('esteira',x,y,(y%2)?1:3))n++;}
    for(const e of ents)if(e.k==='esteira'){for(let k=0;k<2;k++)beltPush(e,'placa_ferro',k*.4+.1,-1)}
    G.p.x=40.5;G.p.y=50.5;
    const t0=performance.now();let frames=0;await new Promise(res=>{const f=()=>{frames++;if(performance.now()-t0<3000)requestAnimationFrame(f);else res()};requestAnimationFrame(f)});
    const t1=performance.now();for(let i=0;i<300;i++)simFactory(1/30);const simMs=(performance.now()-t1)/300;
    const t2=performance.now();for(let i=0;i<60;i++)render(0.016);const renMs=(performance.now()-t2)/60;
    return {belts:n,fps:(frames/3).toFixed(1),simMs:simMs.toFixed(3),renMs:renMs.toFixed(2),ents:ents.length}});
  console.log(perf);
  await p.screenshot({path:'p_perf.png'});
  await b.close();})();
