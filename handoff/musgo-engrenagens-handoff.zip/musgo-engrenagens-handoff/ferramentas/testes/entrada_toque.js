const {start}=require('../lib.js');
(async()=>{const {b,p}=await start({dsf:2});
  const st=()=>p.evaluate(()=>({x:+G.p.x.toFixed(2),y:+G.p.y.toFixed(2),dir:G.p.dir,inv:G.p.inv,auto:!!G.p.auto,sel:G.sel,pn:PN&&PN.title,obj:lastObj.slice(0,50)}));
  console.log(await st());
  // joystick drag right-down for 1s
  const joy=await p.$('#joy');const bb=await joy.boundingBox();const cx=bb.x+bb.width/2,cy=bb.y+bb.height/2;
  await p.mouse.move(cx,cy);await p.mouse.down();await p.mouse.move(cx+40,cy+20,{steps:3});await p.waitForTimeout(1000);await p.mouse.up();
  console.log('after joy',await st());
  // find nearest tree and tap on it (screen coords)
  const tr=await p.evaluate(()=>{let best=null,bd=99;for(let y=30;y<55;y++)for(let x=30;x<55;x++){const o=obj[idx(x,y)];if(o&&o.k==='tree'){const d=Math.hypot(x-G.p.x,y-G.p.y);if(d<bd){bd=d;best=[x,y]}}}
    const [x,y]=best;const r=cv.getBoundingClientRect();return {x,y,sx:r.left+(((x+.5)-(y+.5))*16+VW/2-cam.x)*SC,sy:r.top+(((x+.5)+(y+.5))*8+VH/2-cam.y-14)*SC}});
  console.log('tree',tr);
  await p.mouse.click(tr.sx,tr.sy);
  await p.waitForTimeout(6000);
  console.log('after tree tap',await st());
  await p.screenshot({path:'s_chop.png'});
  // press A a few times / hold
  // open bag, craft tab
  await p.evaluate(()=>{give('pedra',20);give('madeira',5)});
  await p.click('#bagBtn');await p.waitForTimeout(300);
  await p.screenshot({path:'s_bag.png'});
  await p.click('[data-tab="1"]');await p.waitForTimeout(200);
  await p.screenshot({path:'s_craft.png'});
  await p.click('[data-a="craft"][data-id="forno"]');await p.waitForTimeout(200);
  console.log('after craft',await st());
  await p.click('#pHead .x');await p.waitForTimeout(200);
  await p.click('.slot[data-id="forno"]');await p.waitForTimeout(200);
  // tap ground near player to place
  const g=await p.evaluate(()=>{const x=Math.floor(G.p.x)+1,y=Math.floor(G.p.y)+1;obj[idx(x,y)]=null;const r=cv.getBoundingClientRect();return {x,y,sx:r.left+(((x+.5)-(y+.5))*16+VW/2-cam.x)*SC,sy:r.top+(((x+.5)+(y+.5))*8+VH/2-cam.y)*SC}});
  await p.mouse.click(g.sx,g.sy);await p.waitForTimeout(300);
  console.log('placed?',await p.evaluate(([x,y])=>entAt(x,y)&&entAt(x,y).k,[g.x,g.y]),await st());
  // tap on furnace to open panel
  await p.mouse.click(g.sx,g.sy-10);await p.waitForTimeout(300);
  console.log(await st());
  await p.screenshot({path:'s_forno.png'});
  await b.close();})();
