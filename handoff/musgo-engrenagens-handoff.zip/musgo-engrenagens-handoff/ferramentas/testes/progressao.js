const {start}=require('../lib.js');
(async()=>{const {b,p}=await start({dsf:2});
  const shot=async(n)=>{await p.waitForTimeout(400);await p.screenshot({path:n+'.png'})};
  const skip=async()=>{for(let i=0;i<10;i++){const o=await p.evaluate(()=>dlgOpen);if(!o)break;await p.evaluate(()=>{dlgNext();dlgNext()});await p.waitForTimeout(80)}};
  // stage 1 via hub panel
  await p.evaluate(()=>{give('madeira',12);give('pedra',12);openHub()});
  await shot('h_hub');
  await p.click('[data-a="deliver"]');await p.waitForTimeout(500);
  await shot('h_stage');
  console.log(await p.evaluate(()=>({stage:G.stage,coins:G.coins,inv:G.p.inv,dlg:dlgOpen,pn:!!PN})));
  await skip();
  // advance all the way with gives
  for(let s=1;s<5;s++){await p.evaluate(()=>{const st=STAGES[G.stage];for(const k in st.req)give(k,st.req[k]);openHub()});await p.click('[data-a="deliver"]');await p.waitForTimeout(200);await skip();}
  console.log(await p.evaluate(()=>({stage:G.stage,coins:G.coins,obj:objective()})));
  // shop
  await p.evaluate(()=>talkTo('nono'));await skip();await shot('h_shop');
  await p.click('[data-a="up"]');await p.waitForTimeout(100);
  console.log(await p.evaluate(()=>({coins:G.coins,maxhp:G.p.maxhp,shop:G.shop})));
  await p.evaluate(()=>closePanel());
  // bridge
  await p.evaluate(()=>{give('tabua',20);give('placa_ferro',10);openBridge()});await shot('h_bridge');
  await p.click('[data-a="fix"]');await p.waitForTimeout(200);
  console.log(await p.evaluate(()=>({bridge:G.flags.bridge,path:!!findPath(50,40,66,40,false)})));
  await p.evaluate(()=>{G.p.x=59.5;G.p.y=40.5});await shot('h_bridge2');
  // key + gate + boss
  await p.evaluate(()=>{give('chave',1);G.p.x=40.5;G.p.y=22.5;});
  await p.waitForTimeout(300);
  // walk north with keyboard (up-right = N). Hold 'w' + 'd'
  await p.keyboard.down('w');await p.keyboard.down('d');await p.waitForTimeout(1200);await p.keyboard.up('w');await p.keyboard.up('d');
  console.log('at stairs',await p.evaluate(()=>({x:G.p.x.toFixed(2),y:G.p.y.toFixed(2),z:G.p.z.toFixed(2),dir:G.p.dir,t:findTarget()})));
  await shot('h_gate');
  await p.evaluate(()=>pressA());await p.waitForTimeout(300);
  console.log(await p.evaluate(()=>({gate:G.flags.gate,obj:obj[idx(40,19)]})));
  await p.keyboard.down('w');await p.keyboard.down('d');await p.waitForTimeout(3500);await p.keyboard.up('w');await p.keyboard.up('d');
  console.log('in ruins',await p.evaluate(()=>({x:G.p.x.toFixed(2),y:G.p.y.toFixed(2),z:G.p.z.toFixed(2),mobs:mobs.map(m=>m.k)})));
  await p.evaluate(()=>{G.p.x=40.5;G.p.y=11.2;G.p.hp=G.p.maxhp=16;G.p.sword=4;mobs=[]});
  await p.waitForTimeout(2500);
  await shot('h_boss');
  console.log(await p.evaluate(()=>({mobs:mobs.map(m=>[m.k,m.hp,m.st]),hp:G.p.hp})));
  for(let i=0;i<60;i++){const done=await p.evaluate(()=>{const m=mobs.find(m=>m.k==='boss');if(!m)return true;const dx=m.x-G.p.x,dy=m.y-G.p.y;G.p.dir=Math.abs(dx)>Math.abs(dy)?(dx>0?1:3):(dy>0?2:0);G.p.hp=16;pressB();return false});if(done)break;await p.waitForTimeout(320);if(i===8)await shot('h_boss2')}
  await p.waitForTimeout(4200);
  console.log(await p.evaluate(()=>({boss:G.flags.boss,dlg:dlgOpen,drops:drops.map(d=>d.id),rest:obj.filter(o=>o&&o.k==='rest').length})));
  await skip();await p.waitForTimeout(2500);
  console.log(await p.evaluate(()=>({inv:G.p.inv,maxhp:G.p.maxhp,coins:G.coins,obj:objective()})));
  // final stage + ending
  await p.evaluate(()=>{const st=STAGES[G.stage];for(const k in st.req)if(k!=='nucleo_antigo')give(k,st.req[k]);G.p.x=40.5;G.p.y=43.5;G.p.z=0;openHub()});await p.click('[data-a="deliver"]');await p.waitForTimeout(600);
  await shot('h_end1');await skip();await p.waitForTimeout(400);await shot('h_end2');
  await p.evaluate(()=>closePanel());await p.waitForTimeout(1500);await shot('h_end3');
  // save / reload
  await p.evaluate(()=>saveGame());
  const before=await p.evaluate(()=>({stage:G.stage,day:G.day,ents:ents.length,coins:G.coins,inv:Object.keys(G.p.inv).length,bridge:terr.filter(t=>t===T.BRIDGE).length}));
  await p.reload();await p.waitForTimeout(800);await p.tap('#tCont');await p.waitForTimeout(1500);
  const after=await p.evaluate(()=>({stage:G.stage,day:G.day,ents:ents.length,coins:G.coins,inv:Object.keys(G.p.inv).length,bridge:terr.filter(t=>t===T.BRIDGE).length,done:G.done}));
  console.log(before,after);
  await shot('h_loaded');
  await b.close();})();
