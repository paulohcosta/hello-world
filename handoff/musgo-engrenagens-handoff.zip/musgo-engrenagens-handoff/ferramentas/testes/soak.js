const {start}=require('../lib.js');
(async()=>{const {b,p}=await start({dsf:1});
  const r=await p.evaluate(()=>{
    const errs=[];G.stage=5;const ks=Object.keys(BLD);for(const k in ITEMS)give(k,60);
    let placed=0;
    try{
    for(let step=0;step<40000;step++){
      if(step%40===0){IN.jx=Math.random()*2-1;IN.jy=Math.random()*2-1}
      if(Math.random()<.05)pressA();if(Math.random()<.05)pressB();
      if(Math.random()<.03){const k=ks[(Math.random()*ks.length)|0];const x=Math.floor(G.p.x)+ri(-4,4),y=Math.floor(G.p.y)+ri(-4,4);if(placeAt(k,x,y,ri(0,3))){placed++;const e=entAt(x,y);if(e&&(e.k==='montadora'))e.rec=['engrenagem','fio','circuito','liga','tabua'][ri(0,4)];if(e&&e.k==='cozinha')e.rec=['farinha','pao','sopa'][ri(0,2)];if(e&&e.k==='bau')e.inv={min_ferro:20,min_cobre:20,carvao:20,placa_ferro:20,trigo:10,nabo:10}}}
      if(Math.random()<.01){const x=Math.floor(G.p.x)+ri(-3,3),y=Math.floor(G.p.y)+ri(-3,3);plantAt(['sem_nabo','sem_trigo','sem_abobora','sem_baga'][ri(0,3)],x,y)}
      if(Math.random()<.004){const x=Math.floor(G.p.x)+ri(-3,3),y=Math.floor(G.p.y)+ri(-3,3);removeAt(x,y)}
      if(Math.random()<.002){spawnMob(['slime','slimeb','bat','sent'][ri(0,3)],G.p.x+2,G.p.y+1)}
      if(Math.random()<.0005){const x=ri(5,74),y=ri(5,74);if(!solidAt(x,y)){G.p.x=x+.5;G.p.y=y+.5;G.p.z=hgt[idx(x,y)]}}
      if(Math.random()<.001){autoTo(Math.floor(G.p.x)+ri(-6,6),Math.floor(G.p.y)+ri(-6,6),null)}
      if(uiBusy){if(dlgOpen){DQ=[];dlgShow()}if(PN){try{PN.render()}catch(e){errs.push('render '+PN.title+': '+e.message)}closePanel()}}
      if(G.fainted){G.fainted=false}
      G.p.hp=Math.max(G.p.hp,4);
      update(1/30);G.time+=2;if(G.time>=1440){G.time-=1440;G.day++}
      if(step%500===0){render(1/30);updHud();updHot();for(const e of ents){if(!e.fixed&&Math.random()<.3){try{entHtml(e)}catch(er){errs.push('entHtml '+e.k+': '+er.message)}}}}
    }}catch(e){errs.push(e.message+' @ '+(e.stack||'').split('\n').slice(1,4).join(' | '))}
    return {errs:[...new Set(errs)].slice(0,10),placed,ents:ents.length,day:G.day,pos:[G.p.x.toFixed(1),G.p.y.toFixed(1)],kills:G.stats.kills,made:G.stats.made,drops:drops.length,parts:parts.length,mobs:mobs.length,crops:crops.size}});
  console.log(JSON.stringify(r,null,1));
  await p.evaluate(()=>{saveGame()});
  console.log('save size',await p.evaluate(()=>localStorage.getItem(SAVEKEY).length));
  await p.screenshot({path:'soak.png'});
  await b.close();})();
