const {start}=require('../lib.js');
(async()=>{const {b,p}=await start({dsf:2});
  const r=await p.evaluate(()=>{
    // find copper ore tiles
    const ores=[];for(let y=45;y<54;y++)for(let x=43;x<52;x++)if(terr[idx(x,y)]===T.ORE_CU)ores.push([x,y]);
    const fe=[];for(let y=45;y<54;y++)for(let x=30;x<39;x++)if(terr[idx(x,y)]===T.ORE_FE)fe.push([x,y]);
    for(const k of ['broca','catavento','esteira','forno','garra','bau','montadora','divisor','lampiao','aspersor','colhedora','cozinha','coletor','roda','reator'])give(k,30);
    give('carvao',50);give('sem_nabo',20);give('sem_trigo',10);give('sem_abobora',5);give('sem_baga',5);
    G.stage=3;
    G.p.x=44.5;G.p.y=46.5;
    const log=[];
    // clear objects in area
    for(let y=42;y<52;y++)for(let x=40;x<52;x++){obj[idx(x,y)]=null}
    const [ox,oy]=ores[0];
    log.push(['ore',ox,oy,ores.length,fe.length]);
    log.push(placeAt('broca',ox,oy,0)); // output north
    log.push(placeAt('catavento',ox+2,oy-2,0));
    // belts going north from ox,oy-1 up to oy-4, then furnace
    for(let k=1;k<=3;k++)log.push(placeAt('esteira',ox,oy-k,0));
    log.push(placeAt('forno',ox,oy-4,0));
    const f=entAt(ox,oy-4);f.fuel={id:'carvao',n:10};
    log.push(placeAt('garra',ox,oy-5,0));
    log.push(placeAt('bau',ox,oy-6,0));
    // assembler chain: garra from chest west -> montadora
    log.push(placeAt('garra',ox-1,oy-6,3));
    log.push(placeAt('montadora',ox-2,oy-6,0));
    entAt(ox-2,oy-6).rec='fio';
    log.push(placeAt('garra',ox-3,oy-6,3));
    log.push(placeAt('esteira',ox-4,oy-6,2));log.push(placeAt('esteira',ox-4,oy-5,2));log.push(placeAt('esteira',ox-4,oy-4,2));
    log.push(placeAt('divisor',ox-4,oy-3,2));
    log.push(placeAt('esteira',ox-4,oy-2,2));log.push(placeAt('esteira',ox-5,oy-3,3));log.push(placeAt('esteira',ox-3,oy-3,1));
    log.push(placeAt('lampiao',ox+1,oy-3,0));
    // farm
    for(let y=0;y<3;y++)for(let x=0;x<3;x++)log.push(plantAt(['sem_nabo','sem_trigo','sem_abobora'][y],ox-9+x,oy-1+y));
    log.push(placeAt('aspersor',ox-8,oy+2,0));
    window._o=[ox,oy];
    return log;
  });
  console.log(JSON.stringify(r));
  await p.waitForTimeout(25000);
  console.log(JSON.stringify(await p.evaluate(()=>{const [ox,oy]=window._o;return {pw:PW,chest:entAt(ox,oy-6).inv,forno:entAt(ox,oy-4),asm:entAt(ox-2,oy-6),belts:[entAt(ox-4,oy-6).items.length,entAt(ox-4,oy-2).items.length,entAt(ox-5,oy-3).items.length,entAt(ox-3,oy-3).items.length],crops:[...crops].slice(0,4)}})));
  await p.screenshot({path:'s_factory.png'});
  await p.evaluate(()=>{selectItem('garra')});
  await p.waitForTimeout(300);
  await p.screenshot({path:'s_build.png'});
  await b.close();})();
