const {start}=require('../lib.js');
(async()=>{const {b,p}=await start({dsf:1,title:1,w:1180,h:900});
  await p.evaluate(()=>{
    document.body.innerHTML='';document.body.style.background='#8ad06c';
    const c=document.createElement('canvas');c.width=295;c.height=225;c.style.cssText='image-rendering:pixelated;width:1180px;height:900px;position:absolute;left:0;top:0';document.body.appendChild(c);
    const g=c.getContext('2d');g.imageSmoothingEnabled=false;g.fillStyle='#8ad06c';g.fillRect(0,0,295,225);
    const rows=[['idle',0,[0,2]],['walk',0,[0,1,2,3,4,5,6,7]],['walk',1,[0,2,4,6]],['chop',0,[1,3,4,5,7,9]],['chop',1,[1,3,4,5,7]],['mine',0,[2,4,5,7]],['slashA',0,[0,1,2,3,4]],['slashB',1,[1,2,3,4]],['water',0,[2,5,8]],['cast',0,[3,6,9]],['pluck',0,[3]],['wave',0,[3]],['eat',0,[3]],['get',0,[0]],['hurt',0,[0]]];
    let x=-8,y=-4;for(const[an,view,fs]of rows){for(const f of fs){if(x>250){x=-8;y+=44}const fr=charFrame('hero',an,f,view,an[0]==='s'?3:1);g.drawImage(fr.c,6,2,54,56,x,y,54,56);x+=an.startsWith('slash')||an==='chop'||an==='mine'||an==='cast'?40:30}x+=6}
  });
  await p.screenshot({path:'hero_sheet.png'});
  await b.close();})();
