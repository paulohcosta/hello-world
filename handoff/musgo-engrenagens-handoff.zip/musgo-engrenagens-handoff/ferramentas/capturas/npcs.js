const {start}=require('../lib.js');
(async()=>{const {b,p}=await start({dsf:2});
  const shot=async(n)=>{await p.waitForTimeout(350);await p.screenshot({path:n+'.png'})};
  await p.evaluate(()=>{G.p.x=45.5;G.p.y=38.6;G.p.dir=1;G.time=10*60});
  await shot('v_nono');
  await p.evaluate(()=>talkTo('nono'));await p.waitForTimeout(900);await shot('v_dlg');
  await p.evaluate(()=>{DQ=[];dlgShow();closePanel();const o=obj.findIndex(o=>o&&o.k==='npc'&&o.id==='bento');const x=o%MW,y=(o/MW)|0;G.p.x=x+1.5;G.p.y=y+.5;G.p.dir=3;for(const[a,c]of[[1,0],[2,0],[1,1]])obj[idx(x+a,y+c)]=null});
  await shot('v_bento');
  // walking with joystick + night
  await p.evaluate(()=>{G.p.x=40.5;G.p.y=44.5;G.time=21*60;give('esteira',5);G.sel='esteira';dirtyHot=true;IN.jx=.8;IN.jy=.4});
  await p.waitForTimeout(500);await shot('v_walk');
  await p.evaluate(()=>{IN.jx=IN.jy=0});
  await b.close();})();
