const {start}=require('../lib.js');const fs=require('fs');
(async()=>{const {b,p}=await start({dsf:1});
  const which=process.argv[2]||'a';
  const url=await p.evaluate((which)=>{
    for(const s of['#hud','#quest','#hot','#ctl','#toasts','#buildBar'])document.querySelector(s).style.display='none';
    zoomI=2;resize();G.time=12*60;G.stage=3;
    const X=40,Y=47;for(let y=Y-4;y<=Y+4;y++)for(let x=X-4;x<=X+4;x++){obj[idx(x,y)]=null;terr[idx(x,y)]=T.GRASS;crops.delete(idx(x,y))}
    const rows=[];const FW=72,FH=64;
    const setP=(dir)=>{const pl=G.p;pl.x=X+.5;pl.y=Y+.5;pl.dir=dir;pl.act=null;pl.pose=null;pl.fish=null;pl.cool=0;pl.auto=null;pl.iv=0;pl.kx=pl.ky=0;pl.moving=false;cam.x=(pl.x-pl.y)*16;cam.y=(pl.x+pl.y)*8+VH*.07;hitStop=0;shake=0;parts.length=0;drops.length=0;floats.length=0;mobs.length=0};
    const cap=function(n,stepF,every){const fr=[];for(let k=0;k<n;k++){for(let q=0;q<(every||2);q++){if(stepF)stepF(k*(every||2)+q);update(1/60)}cam.x=(G.p.x-G.p.y)*16;cam.y=(G.p.x+G.p.y)*8+VH*.07;render(arguments[3]?1/60:0);const c=document.createElement('canvas');c.width=FW;c.height=FH;c.getContext('2d').drawImage(cv,Math.round(VW/2-FW/2),Math.round(VH/2-VH*.07-FH+16),FW,FH,0,0,FW,FH);fr.push(c)}rows.push(fr)};
    const front=(d)=>[X+DIRS[d][0],Y+DIRS[d][1]];
    if(which==='a'){
      for(const d of[2,3,1,0]){setP(d);const[x,y]=front(d);obj[idx(x,y)]={k:'tree',v:d%2?2:0,hp:9};pressA();cap(15);obj[idx(x,y)]=null}
      for(const d of[2,3]){setP(d);const[x,y]=front(d);obj[idx(x,y)]={k:'rock',v:0,hp:9};pressA();cap(15);obj[idx(x,y)]=null}
    }else if(which==='e'){
      for(const d of[2,3]){setP(d);G.p.sword=d===2?1:3;cap(22,(k)=>{if(k%3===0)pressB()},2)}
      setP(2);{const[x,y]=front(2);obj[idx(x,y)]={k:'tree',v:0,hp:9};for(let k=0;k<30;k++){update(1/60);render(1/60)}pressA();cap(12,null,2,1);obj[idx(x,y)]=null}
      setP(2);give('forno',1);G.sel='forno';cap(4,null,6,1);holdUp('ui_sword');cap(6,null,6,1);G.sel=null;
    }else if(which==='b'){
      for(const d of[2,3,1]){setP(d);G.p.sword=d===2?1:d===3?3:4;const[x,y]=front(d);spawnMob('slime',x+.5,y+.5).hp=99;cap(30,(k)=>{if(k%4===0)pressB()},2);mobs.length=0}
    }else if(which==='c'){
      for(const d of[2,3]){setP(d);const[x,y]=front(d);terr[idx(x,y)]=T.SOIL;crops.set(idx(x,y),{k:'nabo',g:.5,wet:0});pressA();cap(20);crops.get(idx(x,y)).g=1;crops.get(idx(x,y)).wet=240;G.p.cool=0;G.p.act=null;pressA();cap(10);crops.delete(idx(x,y));terr[idx(x,y)]=T.GRASS}
      for(const d of[2,3]){setP(d);const[x,y]=front(d);terr[idx(x,y)]=T.WATER;pressA();cap(14);G.p.fish.t=0;cap(4);G.p.cool=0;pressA();cap(12);terr[idx(x,y)]=T.GRASS}
    }else{
      setP(2);give('pao',2);G.p.hp=2;eat('pao');cap(20,null,3);
      setP(2);holdUp('ui_heart');cap(16,null,3);
      setP(2);give('forno',3);G.sel='forno';cap(6,null,4);IN.jx=-.9;IN.jy=.45;cap(10,null,3);IN.jx=IN.jy=0;G.sel=null;
      setP(2);IN.jx=-.9;IN.jy=.45;cap(16,null,2);IN.jx=.9;IN.jy=-.45;cap(1,null,20);cap(12,null,2);IN.jx=IN.jy=0;
      setP(2);G.sel='forno';placeAt('forno',X-1,Y+1,0);cap(10,null,2);give('sem_nabo',3);plantAt('sem_nabo',X,Y+2);G.p.act=null;plantAt('sem_nabo',X+1,Y+2);cap(8,null,2);G.sel=null;
      setP(3);hurt(1,1,0);cap(10,null,3);
    }
    const W=Math.max(...rows.map(r=>r.length))*FW,H=rows.length*FH,out=document.createElement('canvas');out.width=W*3;out.height=H*3;const g=out.getContext('2d');g.imageSmoothingEnabled=false;g.fillStyle='#222';g.fillRect(0,0,W*3,H*3);
    rows.forEach((r,j)=>r.forEach((c,i)=>g.drawImage(c,i*FW*3,j*FH*3,FW*3,FH*3)));return out.toDataURL()},which);
  fs.writeFileSync('film_'+which+'.png',Buffer.from(url.split(',')[1],'base64'));
  await b.close();})();
