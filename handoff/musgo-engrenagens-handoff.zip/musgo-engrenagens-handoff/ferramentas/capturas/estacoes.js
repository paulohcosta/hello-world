const {start}=require('../lib.js');
(async()=>{const {b,p}=await start({w:900,h:1600});
  const spots={home:[40,43],house:[36,39],lake:[26,57],east:[66,42],bridge:[59,42]};
  const seasons=process.argv[2]?process.argv[2].split(','):['0'];
  await p.evaluate(()=>{zoomI=2;resize();for(const s of['#hud','#quest','#hot','#ctl','#toasts'])document.querySelector(s).classList.add('hide');G.time=12*60;});
  for(const se of seasons){for(const k in spots){await p.evaluate(([x,y,se])=>{G.day=1+se*4;G.weather=0;G.mornDay=G.day;G.p.x=x+.5;G.p.y=y+.5;G.p.z=hgt[idx(x,y)];cam.x=(x-y)*16;cam.y=(x+y)*8;mobs=[];G.p.hp=6},[...spots[k],+se]);await p.waitForTimeout(900);await p.screenshot({path:'z_'+k+se+'.png'});}}
  await b.close();})();
