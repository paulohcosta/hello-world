const {start}=require('../lib.js');
(async()=>{const {b,p}=await start({dsf:1,title:1,w:1280,h:1000});
  await p.evaluate(()=>{
    document.body.innerHTML='';document.body.style.background='#8ad06c';const Z=4;
    const c=document.createElement('canvas');c.width=320;c.height=250;c.style.cssText='image-rendering:pixelated;width:1280px;height:1000px;position:absolute;left:0;top:0';document.body.appendChild(c);
    const g=c.getContext('2d');g.imageSmoothingEnabled=false;g.fillStyle='#8ad06c';g.fillRect(0,0,320,250);
    const row=(y,list,step,x0)=>{let x=x0||0;for(const[k,an,f,v]of list){const fr=mobSprite(k,an,f,v||0).c;g.drawImage(fr,x,y);x+=step}};
    row(0,[['slime','idle',0],['slime','idle',1,1],['slime','prep',1],['slime','jump',0],['slime','land',0],['slime','hurt',0],['slime','die',1],['slime','die',3],['slimeb','idle',0],['slimeb','idle',0,1],['slimeb','jump',0]],29,-4);
    row(28,[['bat','fly',0],['bat','fly',1],['bat','fly',2],['bat','hurt',0],['sent','idle',0],['sent','walk',0,1],['sent','wind',0],['sent','punch',0]],38,-2);
    row(68,[['sent','hurt',0],['sent','die',1],['sent','die',3]],46,-6);
    row(58,[['boss','idle',0],['boss','walk',0],['boss','wind',0]],86,128);
    row(150,[['boss','slam',0],['boss','roar',0,1],['boss','die',2],['boss','rest',0]],80,-10);
  });
  await p.screenshot({path:'mob_sheet.png'});
  await b.close();})();
