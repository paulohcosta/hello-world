const {start}=require('../lib.js');const fs=require('fs');
(async()=>{const {b,p}=await start({dsf:1});
  const which=process.argv[2]||'a';
  const url=await p.evaluate((which)=>{
    for(const s of['#hud','#quest','#hot','#ctl','#toasts','#buildBar','#boss'])document.querySelector(s).style.display='none';
    zoomI=2;resize();G.time=12*60;G.stage=3;G.p.maxhp=40;G.p.hp=40;
    const rows=[];let FW=96,FH=72,CX=0,CY=0;
    const cap=(n,every,stepF)=>{const fr=[];for(let k=0;k<n;k++){for(let q=0;q<every;q++){if(stepF)stepF(k*every+q);G.p.hp=40;update(1/60)}cam.x=CX;cam.y=CY;render(1/60);cam.x=CX;cam.y=CY;const c=document.createElement('canvas');c.width=FW;c.height=FH;c.getContext('2d').drawImage(cv,Math.round(VW/2-FW/2),Math.round(VH/2-FH/2),FW,FH,0,0,FW,FH);fr.push(c)}rows.push(fr)};
    const setup=(x,y,h)=>{mobs.length=0;parts.length=0;drops.length=0;floats.length=0;amb.length=0;G.p.x=x+.5;G.p.y=y+.5;G.p.z=h||0;G.p.dir=3;G.p.act=null;G.p.iv=0;G.p.kx=G.p.ky=0;CX=(x-.5-y)*16;CY=(x-.5+y)*8-(h||0)*HZ-6;hitStop=0;shake=0};
    if(which==='a'){const X=12,Y=40;for(let y=Y-3;y<=Y+3;y++)for(let x=X-5;x<=X+3;x++){obj[idx(x,y)]=null;dec[idx(x,y)]=0}
      setup(X,Y);spawnMob('slime',X-2.5,Y+.5);cap(18,3);cap(14,3,(k)=>{if(k===6)pressB()});cap(14,3,(k)=>{if(k===2||k===20)pressB()});
      setup(X,Y);const m=spawnMob('slimeb',X-2.5,Y+.5);cap(16,3);
      setup(X,Y);spawnMob('bat',X-3.5,Y+.5).h=0;cap(16,3,(k)=>{if(k===30)pressB()});
    }else if(which==='b'){const X=40,Y=15;setup(X,Y,1);spawnMob('sent',X-2.5,Y+.5);cap(18,3);cap(18,3,(k)=>{if(k===20||k===40)pressB()});G.p.sword=6;cap(18,3,(k)=>{if(k===4)pressB()});
    }else{FW=150;FH=110;const X=41,Y=10;setup(X,Y,1);G.flags.boss=0;restGuardian();cap(1,2);G.p.y=11.4;spawner();G.p.x=X+.5;G.p.y=Y+.5;cap(14,6);
      CX=(40-8.5)*16;CY=(40+8.5)*8-HZ-10;cap(14,5);const bm=mobs.find(m=>m.k==='boss');bm.hp=19;cap(14,5);bm.hp=1;G.p.sword=5;G.p.x=bm.x+1.2;G.p.y=bm.y;G.p.dir=3;bm.hit=0;bm.st=0;cap(16,8,(k)=>{if(k===1)hitMob(bm,5,-1,0)});cap(6,10)}
    const W=Math.max(...rows.map(r=>r.length))*FW,H=rows.length*FH,Z=which==='c'?2:3,out=document.createElement('canvas');out.width=W*Z;out.height=H*Z;const g=out.getContext('2d');g.imageSmoothingEnabled=false;g.fillStyle='#222';g.fillRect(0,0,W*Z,H*Z);
    rows.forEach((r,j)=>r.forEach((c,i)=>g.drawImage(c,i*FW*Z,j*FH*Z,FW*Z,FH*Z)));return out.toDataURL()},which);
  fs.writeFileSync('mfilm_'+which+'.png',Buffer.from(url.split(',')[1],'base64'));
  await b.close();})();
