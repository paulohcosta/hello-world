const {start}=require('../lib.js');
(async()=>{const {b,p}=await start({w:1080,h:1500});
  await p.evaluate(()=>{
    zoomI=1;resize();for(const q of['#hud','#quest','#hot','#ctl','#toasts','#buildBar'])document.querySelector(q).style.display='none';
    for(const k of Object.keys(BLD))give(k,60);give('carvao',50);G.stage=5;G.time=11*60;
    const X=38,Y=44;for(let y=Y-3;y<Y+12;y++)for(let x=X-6;x<X+12;x++){const i=idx(x,y);if(!ent[i]||!ent[i].fixed){obj[i]=null;if(ORE[terr[i]]||terr[i]===T.PATH)terr[i]=T.GRASS}}
    for(let x=X;x<X+3;x++)terr[idx(x,Y+6)]=T.ORE_CU;
    G.p.x=X+2.5;G.p.y=Y+5.5;G.p.dir=2;
    // drill -> belts with curves -> furnace -> garra -> chest
    placeAt('broca',X,Y+6,0);placeAt('broca',X+1,Y+6,0);
    for(let y=Y+5;y>=Y+3;y--)placeAt('esteira',X,y,0);
    placeAt('esteira',X,Y+2,1);for(let x=X+1;x<=X+3;x++)placeAt('esteira',x,Y+2,1);placeAt('esteira',X+4,Y+2,0);placeAt('esteira',X+4,Y+1,0);
    placeAt('forno',X+4,Y,0);entAt(X+4,Y).fuel={id:'carvao',n:10};
    placeAt('garra',X+5,Y,1);placeAt('bau',X+6,Y,0);
    placeAt('garra',X+6,Y+1,2);placeAt('montadora',X+6,Y+2,0);entAt(X+6,Y+2).rec='fio';
    placeAt('garra',X+7,Y+2,1);placeAt('divisor',X+8,Y+2,1);placeAt('esteira',X+9,Y+2,1);placeAt('esteira',X+8,Y+3,2);placeAt('esteira',X+8,Y+1,0);
    placeAt('catavento',X+2,Y+4,0);placeAt('catavento',X+8,Y+5,0);placeAt('lampiao',X+5,Y+4,0);
    placeAt('cozinha',X+6,Y+4,0);entAt(X+6,Y+4).rec='sopa';entAt(X+6,Y+4).inv={nabo:30};
    placeAt('reator',X-2,Y+3,0);entAt(X-2,Y+3).fuel=5;
    // farm
    give('sem_nabo',20);for(let y=0;y<3;y++)for(let x=0;x<3;x++){plantAt('sem_nabo',X-4+x,Y+6+y);const c=crops.get(idx(X-4+x,Y+6+y));if(c){c.g=[.2,.6,1][x];c.wet=200}}
    placeAt('aspersor',X-5,Y+7,0);placeAt('colhedora',X-1,Y+7,2);placeAt('bau',X-1,Y+8,0);
    placeAt('coletor',X+10,Y,2);placeAt('bau',X+10,Y+1,0);obj[idx(X+11,Y-1)]={k:'tree',v:0,hp:4};obj[idx(X+12,Y)]={k:'tree',v:1,hp:4};
    window._c=[X,Y];
  });
  await p.waitForTimeout(9000);
  await p.screenshot({path:'m_factory.png'});
  await p.evaluate(()=>{G.time=22*60});await p.waitForTimeout(600);await p.screenshot({path:'m_night.png'});
  console.log(await p.evaluate(()=>({pw:PW,chest:entAt(window._c[0]+6,window._c[1]).inv})));
  await b.close();})();
