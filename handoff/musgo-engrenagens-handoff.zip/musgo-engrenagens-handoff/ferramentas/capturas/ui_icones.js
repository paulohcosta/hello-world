const {start}=require('../lib.js');
(async()=>{
  const {b,p}=await start({title:1,w:900,h:420});
  await p.evaluate(()=>{const d=document.createElement('div');d.style.cssText='position:fixed;inset:0;background:#6a9a6a;z-index:99;padding:8px;display:flex;flex-wrap:wrap;gap:6px;align-content:flex-start';
    for(const k of Object.keys(IURL).filter(k=>k.startsWith('ui_'))){const i=new Image();i.src=IURL[k];i.title=k;i.style.cssText='height:60px;image-rendering:pixelated;background:#fff4dc';d.appendChild(i)}
    const l=new Image();l.src=$('#logoImg').src;l.style.cssText='width:600px;image-rendering:pixelated';d.appendChild(l);document.body.appendChild(d)});
  await p.waitForTimeout(300);await p.screenshot({path:'ui/icons.png'});await b.close();
})();
