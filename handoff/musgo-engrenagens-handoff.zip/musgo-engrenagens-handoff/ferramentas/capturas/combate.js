const {start}=require('../lib.js');
(async()=>{const {b,p}=await start({dsf:2});
  await p.evaluate(()=>{G.p.maxhp=G.p.hp=10;dirtyHud=true;G.time=13*60;G.p.x=13.5;G.p.y=40.5;G.p.dir=3;for(let y=38;y<44;y++)for(let x=9;x<17;x++)obj[idx(x,y)]=null;
    const a=spawnMob('slime',11.5,40.5);a.born=0;a.t=.3;const c=spawnMob('slime',12.2,42.3);c.born=0;c.t=.8;const d=spawnMob('slime',11,38.8);d.born=0;d.t=.95;});
  await p.waitForTimeout(350);await p.screenshot({path:'m_forest.png'});
  await p.evaluate(()=>{mobs.length=0;G.p.x=41.6;G.p.y=10.6;G.p.z=1;G.p.dir=3;G.flags.ruinDay=G.day;spawner()});
  await p.waitForTimeout(4200);await p.screenshot({path:'m_boss.png'});
  await b.close();})();
