const {start}=require('../lib.js');
(async()=>{
  for(const[w,h,n]of[[360,640,'small'],[1280,800,'desk']]){
    let {b,p}=await start({w,h,title:1});await p.waitForTimeout(400);await p.screenshot({path:'ui/v_'+n+'_title.png'});await b.close();
    ({b,p}=await start({w,h}));
    await p.evaluate(()=>{G.stage=2;for(const k of['madeira','pedra','forno','esteira','garra','catavento','broca','sem_nabo','pao'])give(k,12);G.coins=345;G.p.maxhp=16;G.p.hp=9;dirtyHud=true;toast('{sun} Bom dia! · Dia 2');selectItem('broca')});
    await p.waitForTimeout(800);await p.screenshot({path:'ui/v_'+n+'_hud.png'});
    await p.evaluate(()=>{selectItem(null);openBag(1)});await p.waitForTimeout(400);await p.screenshot({path:'ui/v_'+n+'_bag.png'});
    await p.evaluate(()=>{closePanel();say([{w:'nono',t:'Ora, ora, cara nova no vale! Sou a Tia Nonô. Cavo túneis, vendo sementes e não aceito fiado.'}])});await p.waitForTimeout(2500);await p.screenshot({path:'ui/v_'+n+'_dlg.png'});
    await b.close()}
})();
