const {start}=require('../lib.js');
(async()=>{const {b,p}=await start({dsf:2});
  await p.evaluate(()=>{saveGame();toTitle()});await p.waitForTimeout(1600);
  await p.tap('#tNew');await p.waitForTimeout(300);await p.screenshot({path:'ui/30_title_confirm.png'});
  console.log(await p.evaluate(()=>[$('#tNew').textContent,$('#tCont').className,$('#tCont').textContent]));
  await p.tap('#tCont');await p.waitForTimeout(1800);
  await p.evaluate(()=>{say([{w:'bento',t:'Coaxo! Dia bom para pescar, hein? Fique de frente para a água e aperte <b>A</b>.'}])});await p.waitForTimeout(2200);await p.screenshot({path:'ui/31_dlg.png'});
  console.log(await p.evaluate(()=>({ui:!$('#hud').classList.contains('hide'),toast:$('#toasts').textContent})));
  await b.close();})();
