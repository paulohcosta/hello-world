const {start}=require('../lib.js');
(async()=>{
  // título
  let {b,p}=await start({title:1,dsf:2});await p.waitForTimeout(500);await p.screenshot({path:'ui/01_title.png'});await b.close();
  ({b,p}=await start({dsf:2}));
  const shot=async n=>{await p.waitForTimeout(350);await p.screenshot({path:'ui/'+n+'.png'})};
  await shot('02_hud');
  // diálogo
  await p.evaluate(()=>{say([{w:'pip',t:'Abra a <b>Mochila {arrowr} Criar</b> e faça uma <b>Fornalha</b>. O vale agradece! {flower}'}])});await p.waitForTimeout(1500);await shot('03_dlg');
  await p.evaluate(()=>{DQ=[];dlgShow()});
  // dar itens, energia, toasts
  await p.evaluate(()=>{for(const k of['madeira','pedra','forno','esteira','garra','catavento','broca','sem_nabo','pao','placa_cobre','placa_ferro','tabua','carvao','min_cobre'])give(k,12);G.coins=345;G.p.hp=3;dirtyHud=true;toast('{sun} Bom dia! · Dia 2');toast('{gift} Você encontrou 20 moedas!');toast('Nham! Pão (+2 {heart})')});
  await shot('04_hud_items');
  await p.evaluate(()=>{selectItem('esteira')});await shot('05_build');
  await p.evaluate(()=>{selectItem(null);openBag(0)});await shot('06_bag_items');
  await p.evaluate(()=>{PN.it='forno';renderPanel()});await shot('07_bag_item_sel');
  for(const[i,n]of[[1,'08_bag_craft'],[2,'09_bag_clock'],[3,'10_bag_map'],[4,'11_bag_more']]){await p.evaluate(i=>{PN.tab=i;renderPanel(true)},i);await shot(n)}
  await p.evaluate(()=>{closePanel();openShop()});await shot('12_shop');
  await p.evaluate(()=>{closePanel();askSleep()});await shot('13_sleep');
  await p.evaluate(()=>{closePanel();openBridge()});await shot('14_bridge');
  await p.evaluate(()=>{closePanel();openHub()});await shot('15_hub');
  await p.evaluate(()=>{closePanel();$('#tHelp').click()});await shot('16_help');
  await p.evaluate(()=>{closePanel()});
  await b.close();
})();
