const {start}=require('../lib.js');
(async()=>{const {b,p}=await start({dsf:2});
  const shot=async(n)=>{await p.waitForTimeout(400);await p.screenshot({path:n+'.png'})};
  // night with lamp + furnace
  await p.evaluate(()=>{give('lampiao',3);give('forno',1);G.stage=2;obj[idx(42,45)]=null;obj[idx(38,45)]=null;placeAt('lampiao',42,45,0);placeAt('forno',38,45,0);const f=entAt(38,45);f.fuel={id:'carvao',n:5};f.inp={id:'min_ferro',n:8};G.time=22*60;});
  await shot('n_night');
  // autumn rain
  await p.evaluate(()=>{G.day=9;G.time=15*60;G.weather=1;});
  await shot('n_autumn');
  await p.evaluate(()=>{G.day=13;G.time=11*60;G.weather=1;});
  await shot('n_winter');
  await p.evaluate(()=>{G.day=5;G.time=18.5*60;G.weather=0;});
  await shot('n_summer_dusk');
  // combat: spawn slimes near player in forest
  await p.evaluate(()=>{G.day=1;G.time=12*60;G.p.x=14.5;G.p.y=40.5;for(let y=38;y<44;y++)for(let x=11;x<19;x++)obj[idx(x,y)]=null;spawnMob('slime',16.5,40.5);spawnMob('slime',13,42.5);spawnMob('bat',15,38.5);cam.x=(14.5-40.5)*16;cam.y=(55)*8;});
  await p.waitForTimeout(2500);
  await shot('n_combat');
  console.log(await p.evaluate(()=>({hp:G.p.hp,mobs:mobs.map(m=>[m.k,m.x.toFixed(1),m.y.toFixed(1),m.hp])})));
  // swing sword several times facing mob
  for(let i=0;i<14;i++){await p.evaluate(()=>{const m=mobs[0];if(m){const dx=m.x-G.p.x,dy=m.y-G.p.y;G.p.dir=Math.abs(dx)>Math.abs(dy)?(dx>0?1:3):(dy>0?2:0)}pressB()});await p.waitForTimeout(330)}
  console.log(await p.evaluate(()=>({hp:G.p.hp,kills:G.stats.kills,inv:G.p.inv,coins:G.coins,mobs:mobs.length})));
  await shot('n_combat2');
  await b.close();})();
