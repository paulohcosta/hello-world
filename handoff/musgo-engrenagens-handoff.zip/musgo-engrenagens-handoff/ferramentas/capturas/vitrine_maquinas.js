const {start}=require('../lib.js');const fs=require('fs');
(async()=>{const {b,p}=await start({w:900,h:1600});
  const night=process.argv[2]==='night';
  const url=await p.evaluate((night)=>{
    zoomI=1;resize();for(const q of['#hud','#quest','#hot','#ctl','#toasts','#buildBar'])document.querySelector(q).style.display='none';
    for(const k of Object.keys(BLD))give(k,60);G.stage=5;G.time=night?22*60:11*60;
    const X=30,Y=44;for(let y=Y-3;y<Y+14;y++)for(let x=X-3;x<X+14;x++){const i=idx(x,y);obj[i]=null;terr[i]=T.GRASS;crops.delete(i);if(ent[i]&&!ent[i].fixed)delEnt(ent[i])}
    const at=(i,j)=>[X+2*i,Y+2*j];
    const put=(k,i,j,d,f)=>{const[x,y]=at(i,j);if(k==='broca')terr[idx(x,y)]=T.ORE_CU;if(k==='roda')terr[idx(x-1,y)]=T.WATER;placeAt(k,x,y,d||0);const e=entAt(x,y);if(e&&f)f(e);return e};
    const ON=e=>{e.pw=1;e.want=true;e.on=true;e.burn=10;e.ok=true;e.pop=0};
    put('forno',0,0,0,ON);put('forno',1,0,0,e=>{e.pop=0});put('bau',2,0,0,e=>{e.pop=0});put('bau',3,0,0,e=>{e.pop=.14});put('bin',4,0,0,e=>e.pop=0);
    put('broca',0,1,1,ON);put('broca',1,1,2,ON);put('broca',2,1,0,ON);put('broca',3,1,3,e=>{e.pop=0;e.pw=1});put('catavento',4,1,0,e=>e.pop=0);
    put('montadora',0,2,0,e=>{ON(e);e.rec='engrenagem'});put('montadora',1,2,0,e=>{e.pop=0;e.pw=0});put('cozinha',2,2,0,e=>{ON(e);e.rec='pao'});put('divisor',3,2,1,e=>e.pop=0);put('lampiao',4,2,0,e=>e.pop=0);
    put('colhedora',0,3,1,ON);put('colhedora',1,3,0,ON);put('coletor',2,3,2,ON);put('coletor',3,3,3,ON);put('aspersor',4,3,0,e=>e.pop=0);
    put('reator',0,4,0,ON);put('reator',1,4,0,e=>{e.pop=0;e.burn=0});put('roda',2,4,0,ON);
    // garras e esteiras
    {const[x,y]=at(3,4);placeAt('bau',x-1,y,0);placeAt('garra',x,y,1);placeAt('esteira',x+1,y,1);placeAt('esteira',x+2,y,2);placeAt('esteira',x+2,y+1,2);placeAt('esteira',x+2,y+2,3);placeAt('esteira',x+1,y+2,3);placeAt('esteira',x,y+2,0);placeAt('garra',x,y+1,0);
      const g1=entAt(x,y);g1.t=.45;g1.st=1;g1.held='placa_cobre';const g2=entAt(x,y+1);g2.t=.8;g2.st=3;g2.filter='engrenagem';
      for(const[bx,by]of[[x+1,y],[x+2,y],[x+2,y+1],[x+2,y+2],[x+1,y+2],[x,y+2]]){const e=entAt(bx,by);e.items=[];beltPush(e,'placa_ferro',.15,-1);beltPush(e,'engrenagem',.6,-1)}
      for(const e of ents)e.pop=0;entAt(at(3,0)[0],at(3,0)[1]).pop=.14}
    G.p.x=X+4.5;G.p.y=Y+11.5;G.p.z=0;cam.x=((X+4.5)-(Y+4.5))*16;cam.y=((X+4.5)+(Y+4.5))*8+20;
    const cx0=cam.x,cy0=cam.y;PW.ratio=1;PW.any=true;now=3.37;parts.length=0;
    for(let k=0;k<40;k++){for(const e of ents){if(e.k==='forno'&&e.x===X)e.on=true}render(1/30);cam.x=cx0;cam.y=cy0}
    cam.x=cx0;cam.y=cy0;const px=G.p.x;G.p.x=X+20;render(0);G.p.x=px;
    const out=document.createElement('canvas');out.width=cv.width*4;out.height=cv.height*4;const g=out.getContext('2d');g.imageSmoothingEnabled=false;g.drawImage(cv,0,0,out.width,out.height);return out.toDataURL()},night);
  fs.writeFileSync('showroom'+(night?'_n':'')+'.png',Buffer.from(url.split(',')[1],'base64'));
  await b.close();})();
