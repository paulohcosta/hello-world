const {start}=require('../lib.js');
(async()=>{const {b,p}=await start({w:900,h:1600});
  await p.evaluate(()=>{zoomI=0;resize();for(const s of['#hud','#quest','#hot','#ctl'])document.querySelector(s).classList.add('hide');G.time=12*60;});
  const spots={home:[40,41],lake:[24,56],forest:[12,36],quarry:[42,62],bridge:[58,41],east:[69,42],stairs:[40,23],ruins:[40,13],nw:[9,12],se:[68,68]};
  for(const k in spots){await p.evaluate(([x,y])=>{G.p.x=x+.5;G.p.y=y+.5;G.p.z=hgt[idx(x,y)];cam.x=(x-y)*16;cam.y=(x+y)*8;mobs=[];G.p.hp=6},spots[k]);await p.waitForTimeout(700);await p.screenshot({path:'w_'+k+'.png'});}
  await b.close();})();
