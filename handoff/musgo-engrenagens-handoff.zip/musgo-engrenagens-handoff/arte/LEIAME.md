# arte/

PNG exportados da arte procedural de `jogo/index.html` por `ferramentas/exportar_arte.js`.
`indice.json` lista cada arquivo com largura, altura e, quando se aplica, `quadro_w`, `quadro_h`, `quadros`
(tiras horizontais de animação) e âncoras (`ax, ay` ou `ancora`: ponto do sprite que fica no centro do tile).

| Pasta | Conteúdo |
|---|---|
| `icones/` | Ícones 10×10 de itens e interface (`ui_*`), mais `_atlas_10x10.png`; ícones de construções em tamanhos variados |
| `terreno/<estação>/` | Tiles 32×16 por tipo (tiras de variantes), bordas, água animada (4 quadros) |
| `terreno/comum/` | Espuma, terra molhada, margens, corrimão, setas, destaques, sombras |
| `enfeites/<estação>/` | Flores, capim, cogumelos, juncos, folhas caídas |
| `arvores/<estação>/` | Folhosa (3 variações), pinheiro, cerejeira, cristal × 3 tamanhos; tiras de 3 quadros de balanço |
| `objetos/` | Pedras, arbustos, muda, ruínas (muros, portão, pilares, braseiro, estátua), poço, placa, baús |
| `maquinas/` | Uma tira por construção; versões direcionais (`_dir0..3` = N, L, S, O); esteiras por direção e forma |
| `relogio/` | Grande Relógio por estação e etapa (0–6) |
| `personagens/<quem>/` | Tiras 64×64 por animação, `_frente` (direções S e L) e `_costas` (O e N); o jogo espelha para L e N |
| `personagens/extras_*` | Pip, dígitos, balões de aviso |
| `criaturas/<tipo>/` | Tiras por estado; `_furia` = variante agressiva/enfurecida |
| `ferramentas/` | Machado, picareta, martelo, vara, regador, espadas (o jogo as gira por código) |
| `interface/` | Molduras 9 fatias (`f-*`), padrões de barra (`p-*`), botões e direcional (`i-*`), logotipo, retratos |

Tudo está em resolução nativa (1 pixel do jogo = 1 pixel do arquivo). Importar no Godot com filtro **Nearest**.
A arte foi criada para este projeto; pode ser usada e modificada livremente nele.
