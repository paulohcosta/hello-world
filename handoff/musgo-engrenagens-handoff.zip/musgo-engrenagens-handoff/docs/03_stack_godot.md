# 03 — Stack sugerida (Godot 4)

## Resumo

| Camada | Escolha |
|---|---|
| Engine | **Godot 4** (versão estável atual), **GDScript** |
| Pixel art e animação | **Aseprite**, com o addon **Aseprite Wizard** para importar |
| Diálogos | **Dialogic 2** |
| Câmera | **Phantom Camera** |
| IA dos inimigos | **LimboAI** (árvores de comportamento) |
| Testes | **GUT** |
| Efeitos sonoros | **jsfxr** ou **ChipTone** |

Complementos recomendados: **Git** + **Git LFS** (binários de arte/áudio), **VS Code** com a extensão
*godot-tools* (opcional; o editor embutido basta), **Tiled/LDtk não são necessários** — o editor de TileMap do
Godot cobre o caso.

## Por que essa stack

- **Godot 4** é 2D de verdade: `TileMapLayer` isométrico, ordenação por Y, luzes 2D, partículas, UI com 9 fatias
  (`NinePatchRect`/`StyleBoxTexture`). É leve no Windows, gratuito e exporta para Android, iOS, Windows e web.
- **Cenas e scripts são texto** (`.tscn`, `.gd`, `.tres`): versionam bem no git e dá para continuar o
  desenvolvimento assistido do mesmo jeito que foi feito até aqui.
- **GDScript** basta para a simulação neste tamanho de mapa (80×80, centenas de máquinas). Só considere C# se a
  fábrica crescer muito — e confirme antes o suporte de C# para exportação web na versão do Godot escolhida
  (historicamente o Godot 4 não exportava projetos C# para web).
- **Aseprite + Aseprite Wizard**: a arte exportada em `arte/` vira ponto de partida editável; o Wizard importa
  `.aseprite` direto como `SpriteFrames`/`AnimationPlayer`, com tags virando animações.
- **Dialogic 2**: falas com retrato, variáveis e escolhas sem escrever sistema de diálogo. As falas atuais estão no
  `index.html` (procure por `say([`).
- **Phantom Camera**: seguir o jogador com suavização, zonas mortas e transições (título → jogo, foco no chefe).
- **LimboAI**: árvores de comportamento e máquinas de estado para gosmas, morcegos, sentinela e chefe, com depurador visual.
- **GUT**: testes automatizados da simulação (esteiras, garras, energia, etapas) — equivalente aos testes
  headless de `ferramentas/testes/`.

## Instalação no Windows

1. **Godot 4** — baixe a versão estável *Standard* (GDScript) em godotengine.org; é um executável único.
   Em *Editor → Manage Export Templates*, instale os modelos de exportação.
2. **Git** e **Git LFS** — `winget install Git.Git` e `winget install GitHub.GitLFS`, depois `git lfs install`.
3. **Aseprite** — pago (Steam/itch/site) ou compilado a partir do código-fonte. Alternativa gratuita: LibreSprite.
4. **Addons** — pela aba *AssetLib* do editor ou baixando do repositório de cada um para `res://addons/`;
   ative em *Project → Project Settings → Plugins*.
   - Confira na página de cada addon **qual versão acompanha a versão do Godot instalada**. Isso vale
     principalmente para o **LimboAI**, distribuído como GDExtension compilada por versão da engine, e para o
     **Dialogic 2**.
   - No **Aseprite Wizard**, informe o caminho do `aseprite.exe` nas configurações do addon.
5. **Android (quando for exportar)** — Android Studio (SDK + plataforma), JDK 17 e a configuração em
   *Editor Settings → Export → Android*. Teste cedo em um aparelho real: é o alvo principal (9:16).

## Configuração do projeto (pixel art, retrato)

| Onde | Valor |
|---|---|
| Rendering → Textures → Default Texture Filter | **Nearest** |
| Rendering → 2D → Snap 2D Transforms to Pixel | ligado |
| Display → Window → Size → Viewport | **216 × 384** (9:16; ajuste após testar no aparelho) |
| Display → Window → Stretch → Mode | `viewport` |
| Display → Window → Stretch → Aspect | `expand` (aproveita telas mais altas que 16:9) |
| Display → Window → Stretch → Scale Mode | `integer` (pixels sempre inteiros; opção das versões 4.x mais recentes) |
| Display → Window → Handheld → Orientation | `portrait` |
| Renderer | **Compatibility** (melhor para celular e web em 2D) |
| Physics → Common → Physics Ticks per Second | 60 (a simulação da fábrica roda em passo fixo próprio de 30 Hz) |

O protótipo usa losangos de **32×16 px**, **12 px por nível de altura** e 4 níveis de zoom inteiros.
No Godot: `TileSet` com *Tile Shape = Isometric*, *Tile Size = 32×16*; camadas de terreno com Y-sort; sprites
altos (árvores, máquinas) como cenas ou tiles com `texture_origin` ajustado pela âncora (`arte/indice.json`).

## Estrutura de projeto proposta

```
res://
├─ project.godot
├─ addons/                 dialogic, phantom_camera, limboai, gut, AsepriteWizard
├─ data/                   JSONs de dados/ (itens, receitas, etapas…) ou .tres gerados a partir deles
├─ art/                    PNGs (de arte/) — icones, terreno, arvores, maquinas, personagens, criaturas, interface
├─ art_src/                .aseprite editáveis (fora do export)
├─ audio/sfx, audio/music
├─ scenes/
│  ├─ main.tscn            raiz: mundo + HUD + câmera
│  ├─ world/               world.tscn (TileMapLayers), tree.tscn, rock.tscn, ruins…
│  ├─ factory/             uma cena por construção (visual); a lógica fica em scripts/factory
│  ├─ actors/              player.tscn, npc.tscn, slime.tscn, bat.tscn, sentinel.tscn, boss.tscn
│  └─ ui/                  hud.tscn, bag.tscn, machine_panel.tscn, shop.tscn, title.tscn
├─ scripts/
│  ├─ autoload/            db.gd (dados), game.gd (estado), sim.gd (fábrica 30 Hz), clock.gd (tempo/estações),
│  │                       save.gd, audio.gd, events.gd (sinais globais)
│  ├─ factory/             grid.gd, belt.gd, inserter.gd, furnace.gd, assembler.gd, power.gd…
│  ├─ world/  actors/  ui/
├─ dialogic/               timelines e personagens
├─ ai/                     árvores do LimboAI
└─ test/                   testes GUT (unit: simulação; integration: cenas)
```

### Princípios de arquitetura para o porte

1. **Simulação separada do visual.** A fábrica é dado puro (grade + listas de entidades) dentro de um autoload,
   atualizada em passo fixo de 30 Hz. As cenas só *mostram* o estado. Isso mantém o desempenho, facilita o save e
   permite testar com GUT sem abrir cena nenhuma.
2. **Itens nas esteiras não são nós.** Desenhe todos com um único nó (`_draw` ou `MultiMeshInstance2D`); um nó por
   item não escala.
3. **Dados fora do código.** Itens, receitas, etapas e loja vêm de `data/` (JSON ou `Resource`), como em `dados/`.
4. **Sinais globais** (`events.gd`) para HUD e áudio reagirem (`stage_advanced`, `coins_changed`, `item_crafted`…).
5. **Save em `user://save.json`** com versão de formato, espelhando o save atual (`G`, terreno alterado, objetos, plantas, entidades).
6. **Interface com `Control`**: as molduras de `arte/interface/f-*.png` são 9 fatias prontas para `StyleBoxTexture`
   (margens em px estão nas regras `border-image` do CSS do protótipo: 3, 4 ou 6 px conforme a moldura).

## Alternativa considerada

**Unity** só compensa se o critério principal for a maior loja de assets: é mais pesada, o build web é pior e o
fluxo 2D é menos direto. A recomendação continua sendo Godot.
