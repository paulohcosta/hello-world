# 02 — Arquitetura do protótipo (`jogo/index.html`)

Um único arquivo de ~2 300 linhas / ~270 KB, sem bibliotecas. Estrutura: `<style>` (CSS da interface),
marcação do HUD/painéis e um `<script>` com todo o jogo. Canvas 2D em baixa resolução para o mundo;
DOM/CSS por cima para a interface.

> As linhas são densas (muito código por linha). Use a busca por nome de função em vez de ler de cima a baixo.

## Mapa de seções (número de linha aproximado)

| Linha | Seção | Conteúdo |
|---|---|---|
| 1–200 | CSS + marcação | Molduras 9 fatias via `border-image`, HUD em fluxo (`#top`), controles, painel, diálogo, título |
| 233 | Utilidades | `clamp`, `lerp`, RNG (`mulberry32`, `hash2`), ruído (`vnoise`, `fbm`), constantes `TW=32, TH=16, HZ=12, MW=MH=80`, `DIRS` (N,L,S,O) |
| 249–394 | **Dados** | `T` (terrenos), `ORE`, `ITEMS`, `BLD`, `REC`, `SMELT`, `CROPS`, `STAGES`, `SHOP` |
| 395–890 | **Arte** | Primitivas de pixel (`mk`, `P`, `R`, `ball`, `outline`, `ascii`, `isoBox`), ícones (`SH`, `mkIcon`), terreno por estação (`genTerrain`), enfeites (`genDecor`), árvores (`treeSprite`), objetos (`genObjects`), máquinas (`MC`, `mbox`…, `genBuildings` → `SPB`), Relógio (`hubSprite`) |
| 891–1065 | Personagens articulados | `LOOKS`, `drawChar`, ferramentas (`TOOLS`), animações por quadros-chave (`HANIM`, `kfAnim`), cache `charFrame` |
| 1066–1157 | Criaturas | `drawSlime/Bat/Sent/Boss`, `mobSprite` (cache por estado) |
| 1158–1259 | Arte da interface | `UISH` (ícones), `mkFrame` (9 fatias), `circBtn`, `genUI`, `drawDial`, `genArt` |
| 1271–1393 | **Mundo** | `newState`, entidades (`mkEnt/addEnt/delEnt/entAt`), `genWorld`, `buildScenery`, `saveGame/loadGame`, inventário (`give/spend/pay`) |
| 1394–1513 | **Simulação da fábrica** | Esteiras, garras, fornalha, montadora, demais máquinas, energia (`PW`), etapas (`hubGive/advanceStage`), plantas, tempo e clima |
| 1514–1548 | Efeitos | Partículas, textos flutuantes, drops, vida ambiente |
| 1549–1679 | Jogador | Entrada (`IN`), colisão, `findPath` (A*), ações (`ACTS`, `doAct`, `applyAct`), espada, `updPlayer` |
| 1680–1745 | Criaturas (lógica) | `MOBD`, `spawnMob`, `updMobs`, chefe, `spawner` |
| 1746–1768 | Construir | `canPlace`, `placeAt`, `plantAt`, `removeAt`, `selectItem` |
| 1769–2007 | **Renderização** | `resize`, `scr2tile`, `entFrame`, `beltShape`, `drawMob`, `drawHero`, `render` |
| 2008–2228 | Interface | `toast`, diálogo, `objective`, `updHud`, `updHot`, painéis (`openPanel/renderPanel`), mochila, máquinas (`entHtml/entAct`), loja, ponte, casa, final, `wireInput` |
| 2229–2288 | Áudio | WebAudio: `sfx(nome)` sintetizado, música generativa (`MODES`, `musicTick`) |
| 2289–fim | Laço principal | `update`, `frame`, `startGame`, `toTitle`, `boot` |

## Estado

- `G` — estado serializável: `seed, day, time (min), weather, stage, hub{item:n}, coins, p{…}, flags{…}, stats{…}, shop{…}, sel, rot, mode`.
  - `G.p` — jogador: `x,y,z,dir,hp,maxhp,inv{id:n},sword,tool,boots,act,pose,fish,auto,cool,iv`.
- Grades `Uint8Array`/arrays de 80×80 indexadas por `idx(x,y)=y*80+x`:
  `terr` (terreno), `hgt` (altura 0/1), `obj` (árvore, pedra, arbusto, ruína, NPC…), `ent` (construção no tile), `pwGrid` (cobertura de energia).
- Listas: `ents` (construções), `mobs`, `drops`, `parts` (partículas), `floats`, `crops` (`Map idx → {k,g,wet}`), `regrow`.
- Save: `localStorage['musgo_engrenagens_v1']` = `{G, terr (string), obj [[i,o]…], crops, ents}`. Autosave a cada 30 s, ao dormir e ao concluir etapa.

## Entidades (construções)

`{k, x, y, d}` + campos por tipo. Direção `d` = índice em `DIRS`.

| Tipo | Campos |
|---|---|
| esteira | `items: [{id, pos (0..1), f (direção de entrada)}]` ordenados do mais adiantado ao mais atrasado |
| garra | `st` (0 espera, 1 indo, 2 soltando, 3 voltando), `t`, `held`, `filter`, `cd` |
| forno | `inp{id,n}`, `fuel{id,n}`, `out{id,n}`, `burn`, `prog`, `on` |
| montadora/cozinha | `rec`, `inv{}`, `out{id,n}`, `prog`, `want` |
| broca | `buf`, `prog`, `want` |
| divisor | `item`, `rr` (rodízio), `cd`, `ld` |
| bau/colhedora/coletor | `inv{}` |
| reator | `fuel`, `burn` |
| todas com energia | `pw` (coberta), `want` (quer trabalhar), `pop` (animação de "pulo") |

## Simulação (30 Hz, passo fixo)

`update(dt)` acumula tempo e chama `simFactory(1/30)`. A interface de transferência é uniforme:

- `canAccept(e, id)` / `accept(e, id)` — a entidade pode/recebe um item.
- `outputs(e)` / `takeOut(e, id)` — itens que podem ser retirados (usado pela garra).
- `eject(e, id)` — empurra um item para o tile à frente (broca, colhedora, cabana).

Regras que definem o "jeito" do jogo (devem ser preservadas no porte):

- **Esteira:** itens avançam `BSPD=1.7` por segundo, mantendo `GAP=0.34` entre si; o primeiro, ao chegar em `pos≥1`,
  passa para a esteira seguinte (em `pos=0`) ou é entregue via `accept`; não entra em esteira de sentido oposto.
- **Garra:** ciclo de 0,38 s para ir e 0,38 s para voltar; só pega se o destino aceitar.
- **Energia:** `updPower` soma geração e demanda (só de máquinas cobertas que `want`); `ratio=min(1, sup/dem)` multiplica o progresso.
- **Reator:** só consome cristal quando `dem > base` (geração que não depende de combustível).
- **Relógio:** `hubGive` acumula em `G.hub`; ao completar todos os requisitos chama `advanceStage`.

## Jogador e ações

- Movimento contínuo em tiles fracionários; colisão por círculo (`PR=0.22`) contra tiles sólidos e diferença de altura (escadas ligam níveis).
- Toque no chão → `findPath` (A*) → `p.auto`. Toque em alvo → vai até lá e age.
- `findTarget()` decide a ação do botão A pelo tile à frente; `ACTS[ação] = [animação, duração (s), instante do impacto (s), usa ferramenta]`.
- `doAct` cria `p.act={an,t,d,hit,fn}`; o efeito (`applyAct`) acontece no instante `hit` da animação (dano na árvore, item colhido etc.).
- Espada: `pressB → startSlash → swordHit`; combo de três toques (`slashA`, `slashB`, giro em área com raio 1,8 e +1 de dano); `hitStop` e `quake` dão peso.

## Criaturas

Máquina de estados simples por tipo dentro de `updMobs` (perseguir, preparar, atacar, atordoado), com campos
`born/bt` (nascimento), `die/dieT` (morte), `hit` (clarão), `ag` (agressivo), `st/st_t/st_d` (estado do ataque).
O chefe tem um golpe no chão com área telegrafada (preparo → pancada) e fase de fúria abaixo de metade da vida. `spawner()` cria criaturas por região e hora.

## Renderização

- Canvas em baixa resolução, escalado por inteiro (4 níveis de zoom). Projeção: `sx=(x−y)·16`, `sy=(x+y)·8 − altura·12`.
- `render` percorre os tiles visíveis de trás para frente e desenha em camadas por tile: terreno, bordas, enfeites,
  planos (esteiras, caminhos), objetos/construções/personagens ordenados por profundidade.
- Luz global vinda de cima-esquerda em todos os sprites. Noite: tinta de ambiente + camada de luz (`lightC`) com halos de lampiões, fornalhas e do Relógio.
- Objetos altos que cobrem o jogador ficam translúcidos (árvores, Relógio, casa).
- Toda a arte é gerada em `genArt()` no `boot` e guardada em caches (`ICON`, `TS`, `OBJ`, `SPB`, `BELT`, `HFC`, `MOBC`, `TREEC`…).
  **`ferramentas/exportar_arte.js` grava esses caches como PNG em `arte/`.**

## Interface

- DOM por cima do canvas. Molduras são imagens 9 fatias geradas em `genUI()` e injetadas como variáveis CSS (`--f-*`, `--p-*`, `--i-*`).
- Textos usam *tokens* `{nome}` que `fx()` troca por ícones em pixel (`{bolt}`, `{heart}`, `{arrowr}`…).
- Painéis: `openPanel({title, icon, tabs, render(), on(a,id), live, after()})`; cliques delegados por `data-a` / `data-id` / `data-tab`.
- Diálogo: fila `DQ` de `{w: quem, t: texto}` com efeito de máquina de escrever (`say`, `dlgShow`, `dlgNext`).

## Áudio

WebAudio puro. `sfx(nome)` monta cada efeito com osciladores e ruído filtrado; a música é generativa
(3 modos: dia, noite, ruínas — escala, acordes e BPM em `MODES`). Nada disso é reaproveitável como arquivo;
no porte, recriar com jsfxr/ChipTone e música de pack ou composta.
