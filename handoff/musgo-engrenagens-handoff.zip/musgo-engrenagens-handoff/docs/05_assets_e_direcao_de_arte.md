# 05 — Assets e direção de arte

## Direção atual

- Pixel art isométrica em baixa resolução: tile 32×16, personagens em quadro 64×64 (corpo ~16×24), ícones 10×10.
- Contorno escuro (`#3a2b35` e variações), luz global de cima-esquerda, paleta quente e saturada por estação
  (`dados/paletas.json`).
- Personagens de cabeça grande e olhos expressivos (traço "anime"); máquinas de madeira, latão e pedra com
  engrenagens aparentes; interface de madeira e papel com rebites dourados.
- Tudo foi desenhado por código. `arte/` contém a exportação completa em PNG (ver `arte/LEIAME.md`).

## Decisão de perspectiva (a mais importante antes de começar)

Pixel art **isométrica** é o estilo com menos assets prontos. Três caminhos:

| Caminho | Prós | Contras |
|---|---|---|
| **A. Manter isométrico em pixel** (padrão deste pacote) | Preserva a identidade; toda a arte exportada serve de base imediata; combina com a stack (Aseprite) | Quase tudo novo continua sendo feito sob medida |
| **B. Mudar para top-down 3/4** (perspectiva de Stardew e Minish Cap) | É onde há mais packs prontos e coesos de fazenda, vila e masmorra; tilemap e colisão mais simples | Descarta terreno, árvores e máquinas atuais; perde o 2,5D |
| **C. 3D low-poly com câmera ortográfica + filtro de pixelização** | Mantém o 2,5D; luz, sombra e rotação de graça; muitos modelos CC0 | Troca o pipeline (Blender em vez de Aseprite); máquinas próprias precisam ser modeladas |

**Sugestão:** começar pelo **A** usando a arte exportada como *placeholder*, para chegar rápido a um jogo rodando
no Godot, e reavaliar no fim do M3. Se a prioridade passar a ser volume de assets prontos, o caminho é o B;
se for o maior salto visual, o C. A simulação e os dados não mudam em nenhum dos três.

## Onde achar assets

| Fonte | O que tem | Licença típica |
|---|---|---|
| **itch.io** (seção *Game assets*) | A maior oferta de pixel art: tilesets, personagens, interface, efeitos, música | Varia por pack (muitos pagos e baratos); ler a licença de cada um |
| **Kenney.nl** | Interface, ícones, áudio, tiles e modelos 3D | CC0 |
| **OpenGameArt.org** | De tudo, qualidade irregular | CC0, CC-BY, CC-BY-SA, GPL — conferir item a item |
| **Quaternius**, **KayKit** | Modelos 3D low-poly (caminho C) | CC0 |
| **Godot Asset Library** | Addons e ferramentas, poucos assets de arte | Em geral MIT |
| **Freesound.org** | Efeitos sonoros | CC0 / CC-BY |

Termos de busca úteis: *isometric pixel tileset*, *cozy farm tileset*, *top-down RPG 16x16*, *pixel UI kit*,
*factory/conveyor pixel*, *chiptune cozy music*.

## Cuidados

- **Coesão:** misturar packs de autores diferentes deixa o visual inconsistente. Escolha um ou dois autores como
  base (mesma resolução, mesma paleta, mesmo tipo de contorno) e adapte o resto no Aseprite.
- **Resolução:** mantenha um único tamanho de pixel no jogo inteiro (nada de sprites em escalas diferentes).
- **Licenças:** guarde um `CREDITOS.md` no repositório com autor, link e licença de cada asset; CC-BY exige
  crédito, CC-BY-SA e GPL têm obrigações de compartilhamento que podem não servir.
- **Máquinas de fábrica** (esteiras, garras, brocas) raramente existem prontas no estilo certo: conte com
  arte própria para elas — as tiras de `arte/maquinas/` já cobrem todas.

## Áudio

Os efeitos e a música do protótipo são sintetizados em tempo real e não existem como arquivo.
- Efeitos: recriar no **jsfxr** ou **ChipTone** (exportar `.wav`), seguindo a lista de `sfx()` no `index.html`
  (passos, corte, mineração, colocar, coletar, moeda, fanfarra, dano, espada, giro, água, comer, dormir…).
- Música: três climas (dia calmo ~88 BPM, noite ~66 BPM, ruínas ~104 BPM; escalas e acordes em `dados/musica.json`).
  Usar packs de música ou compor.

## Fontes de texto

O protótipo usa a fonte arredondada do sistema. No Godot, usar uma fonte pixel com acentos do português
(conferir cobertura de `ã õ ç á é í ó ú â ê ô`) — há várias gratuitas no itch.io e no Google Fonts.
