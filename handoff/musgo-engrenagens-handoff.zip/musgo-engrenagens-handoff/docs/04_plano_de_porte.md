# 04 — Plano de porte (HTML → Godot 4)

## Estratégia

Portar **por camadas jogáveis**, mantendo o protótipo HTML como referência de comportamento.
Cada marco termina com algo que roda no aparelho e com testes GUT das regras envolvidas.
Não tentar traduzir o `index.html` linha a linha: ele é denso e acoplado ao DOM/canvas. Traduzir **regras e dados**.

## O que se reaproveita

| Do protótipo | Como usar |
|---|---|
| Design, textos, falas, balanceamento | `docs/01_design_do_jogo.md`; falas no `index.html` (`say([…])`, `talkTo`, `objective`) |
| Tabelas (itens, receitas, etapas, loja, plantações, criaturas) | `dados/*.json` → carregar em `db.gd` ou converter para `Resource` |
| Mapa inicial 80×80 | `dados/mapa.json` → script de importação que pinta os `TileMapLayer` e instancia objetos |
| Regras da fábrica | `docs/02…` (seção Simulação) + código das funções `canAccept/accept/outputs/takeOut/eject/upd*` |
| Arte | `arte/` (PNG) como base ou *placeholder*; `arte/indice.json` traz quadros e âncoras |
| Molduras e ícones da interface | `arte/interface/` e `arte/icones/` |
| Casos de teste | `ferramentas/testes/*.js` descrevem cenários a recriar em GUT |

**Não se reaproveita:** renderização em canvas, interface em DOM/CSS, áudio sintetizado, rig procedural dos personagens
(use as tiras exportadas ou redesenhe no Aseprite).

## Equivalências

| Protótipo (JS) | Godot 4 |
|---|---|
| `terr`, `hgt` (grades) | `TileMapLayer` (terreno) + segunda camada/altura; dados em `PackedByteArray` no autoload |
| `obj[i]` (árvore, pedra…) | Cenas instanciadas sob um nó com Y-sort, ou tiles de cena |
| `ents`, `ent[i]` | `sim.gd`: dicionário/grade de entidades (dados) + nós visuais por construção |
| `simFactory(1/30)` | Acumulador em `_process` do autoload `sim.gd` (passo fixo de 1/30 s) |
| `render()` com ordenação manual | Y-sort do Godot; itens de esteira num único nó desenhado |
| `charFrame`/`HANIM` | `AnimatedSprite2D` com `SpriteFrames` (tiras de `arte/personagens/`) ou `AnimationPlayer` |
| `ACTS` + `applyAct` no instante `hit` | Faixa de chamada de método no `AnimationPlayer` (ou sinal no quadro de impacto) |
| `findPath` (A*) | `AStarGrid2D` |
| `updMobs` (estados à mão) | Árvores de comportamento do LimboAI |
| `say()/DQ` | Timelines do Dialogic 2 |
| Câmera (`cam`, zoom, `quake`) | Phantom Camera + ruído/tremor |
| Painéis DOM (`openPanel`) | Cenas `Control` com `StyleBoxTexture` 9 fatias |
| `toast()` | Cena de aviso empilhada num `VBoxContainer` |
| Luz noturna (`lightC`) | `CanvasModulate` + `PointLight2D` (lampião, fornalha, Relógio) |
| Partículas (`parts`, `puff`, `spark`) | `GPUParticles2D`/`CPUParticles2D` |
| `sfx(nome)` / música generativa | `AudioStreamPlayer` com arquivos (jsfxr/ChipTone) e trilhas em loop |
| `localStorage` | `FileAccess` em `user://save.json` |
| Tokens `{bolt}` em texto | `RichTextLabel` com `[img]` |

## Marcos

| Marco | Entrega jogável | Testes |
|---|---|---|
| **M0 — Base** | Projeto Godot configurado (pixel perfeito, retrato), addons instalados, `data/` e `art/` importados, repositório com `.gitignore`/LFS, exportação Android "hello world" no aparelho | GUT rodando com 1 teste |
| **M1 — Mundo** | Mapa 80×80 importado de `mapa.json`, estações trocando o tileset, câmera, jogador andando (direcional virtual + toque com `AStarGrid2D`), colisão e escadas | pathfinding, colisão |
| **M2 — Coleta** | Cortar, minerar, colher arbustos; drops; inventário; HUD (corações, moedas, relógio); barra de itens | inventário |
| **M3 — Fábrica 1** | Colocar/girar/desmontar; esteira (arrastar, curvas), garra (filtro), fornalha, baú, broca | **esteira, garra, fornalha** (portar `testes/fabrica.js`) |
| **M4 — Fábrica 2** | Energia (cata-vento, roda, reator), montadora, divisor, Caixa de Envio, Relógio com as 6 etapas e painéis das máquinas | energia, receitas, etapas |
| **M5 — Fazenda e tempo** | Plantar, regar, crescer, colher, aspersor, colhedora, cozinha, cabana; dia/noite, clima, estações, dormir | crescimento, estações |
| **M6 — Aventura** | Espada (combo e giro), criaturas com LimboAI, zonas seguras, ponte, portão, ruínas, chefe, baús | dano, drops, chefe |
| **M7 — Interface e história** | Mochila com abas, loja, diálogos (Dialogic), missão guiada (`objective`), título, save/load, final | save/load ida e volta |
| **M8 — Polimento** | Áudio, partículas, transições, desempenho no aparelho, exportações Android/web/Windows | soak (ações aleatórias) |

Sugestão de ordem real de trabalho: M0 → M1 → **M3** (provar cedo o coração do jogo) → M2 → M4 → M5 → M6 → M7 → M8.

## Testes de equivalência (portar para GUT)

Cenários verificados no protótipo que servem de critério de aceite:

- **Esteira:** itens andam 1,7 tile/s com espaçamento mínimo de 0,34; não entram em esteira de sentido oposto; uma fila
  parada não perde nem duplica itens.
- **Garra:** move 1 item por ciclo (~0,76 s + espera); respeita filtro; não pega se o destino não aceita.
- **Fornalha:** 1 minério + combustível → 1 placa em 3 s; para com saída em 20; madeira queima 6 s, carvão 16 s.
- **Cadeia completa:** broca → esteira → fornalha → garra → baú produz placas continuamente com energia suficiente.
- **Energia:** com demanda acima da geração, o progresso das máquinas cai na proporção `geração/demanda`.
- **Etapas:** entregar por garra/esteira conta igual a entregar à mão; completar requisitos avança a etapa e dá o presente.
- **Progressão inteira:** das 6 etapas ao final, incluindo ponte, portão, chefe e save/load no meio (`testes/progressao.js`).
- **Soak:** dezenas de milhares de passos com ações aleatórias sem erro (`testes/soak.js`).

## Riscos e decisões em aberto

1. **Perspectiva e fonte da arte** — ver `docs/05`. Decidir antes do M1, porque muda o tileset e todo o pipeline de arte.
2. **Tamanho da tela base** (216×384 é um ponto de partida) — validar no aparelho real no M0.
3. **Compatibilidade de versões dos addons** com a versão do Godot — conferir no M0; se o LimboAI ou o Dialogic
   travarem a versão, fixe a versão do Godot do projeto.
4. **Web** continua sendo alvo? Se sim, testar exportação web desde o M1 (áudio e desempenho no navegador do celular).
5. **Escopo de arte** — a arte exportada cobre o jogo inteiro, mas foi desenhada por código em baixa resolução;
   decidir o que será refeito no Aseprite e o que virá de packs.
