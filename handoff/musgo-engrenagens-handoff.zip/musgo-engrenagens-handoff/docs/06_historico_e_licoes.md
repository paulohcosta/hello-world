# 06 — Histórico e lições

## Rodadas (commits do protótipo)

| # | Rodada | Resultado |
|---|---|---|
| 1 | Jogo completo | Mundo, fábrica, fazenda, combate, chefe, loja, NPCs, save, áudio — tudo em um HTML |
| 2 | Personagem e ferramentas | Herói articulado com animações por quadros-chave; ferramentas com impacto no quadro certo |
| 3 | Máquinas | Todas as construções redesenhadas, animadas, com luz única de cima-esquerda e partículas |
| 4 | Cenário | Terreno, vegetação, água, ruínas, Grande Relógio por etapa, vida ambiente, estações |
| 5 | Inimigos | Sprites por estado (nascer, andar, preparar, atacar, apanhar, morrer), chefe com fúria |
| 6 | Interface | Molduras 9 fatias, ícones em pixel no lugar de emoji, logotipo, mostrador do dia, HUD em fluxo |

O histórico completo está em `historico/musgo.bundle` (`git clone historico/musgo.bundle`).

## O que foi verificado e como

- Scripts Playwright em Chromium headless: cadeia de fábrica, entrada por toque real, progressão completa até o
  final com save/load, gestos (arrastar esteira, desmontar), fazenda, cenário, áudio e desempenho (~60 fps com
  ~300 esteiras), além de um *soak* de 40 mil passos com ações aleatórias.
- **Não verificado:** celular real, iOS/Safari, sensação das animações em movimento (só quadros parados),
  balanceamento com jogadores.

## Bugs encontrados (valem como casos de teste no porte)

- Nome de campo reutilizado (`inv` para inventário e para invulnerabilidade) → separar bem os nomes do estado.
- Arrastar em modo desmontar pulava a primeira esteira; tocar para colocar o último item disparava "andar até lá".
- Painel que se redesenha ao vivo engolia toques → não recriar a interface enquanto o dedo está na tela.
- Árvores escondiam o jogador durante a ação → objetos altos ficam translúcidos quando cobrem o herói.
- Drops importantes (chave, núcleo do chefe) podiam cair em lugar inalcançável → drops-chave voam até o jogador;
  os demais voltam se caírem em tile sólido.
- Reator queimava cristal sem demanda → só consome quando a demanda passa da geração de base.
- HUD com muitos corações sobrepunha a caixa de missão → empilhar HUD, missão, barra do chefe e avisos em fluxo.
- Saída de máquina (colhedora/cabana) só tentava ejetar o primeiro item do inventário.

## Lições para a nova stack

1. **Dados em tabelas** foram o que mais facilitou evoluir o jogo; manter isso (e mover para arquivos).
2. **Interface uniforme de transferência** (`canAccept/accept/outputs/takeOut/eject`) deixou cada máquina nova
   barata de adicionar. Portar essa interface antes de qualquer máquina.
3. **Passo fixo de simulação** separado do desenho evitou diferenças entre aparelhos.
4. **Efeito no quadro de impacto** (não no início da animação) é o que dá peso às ferramentas e à espada.
5. **Teste automatizado desde cedo**: o soak e o teste de progressão pegaram a maioria dos erros de regressão.
6. **Limite do arquivo único**: a partir de ~2 000 linhas densas ficou caro mexer com segurança. É o principal
   motivo para migrar.

## Limites conhecidos do protótipo

- Mapa fixo (semente 1337); não há geração de mundo variada nem expansão do mapa.
- Rede de energia única e global (sem cabos nem redes separadas).
- Sem multitoque avançado além de direcional + botões + pinça.
- Sem localização: textos em português embutidos no código.
- Save apenas no `localStorage` do navegador (um único espaço).
