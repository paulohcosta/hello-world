# 01 — Design do jogo

## Conceito

**Musgo & Engrenagens** é um jogo *cozy* 2,5D isométrico para celular em pé (9:16).
Mistura fazenda (Stardew Valley), automação (Factorio) e aventura de ação (Zelda: The Minish Cap),
**com predominância da automação**. Estilo visual entre o pixel art e o anime: paleta quente, contornos
escuros, personagens de cabeça grande.

**Premissa:** o Grande Relógio, que fazia as estações girarem no Vale do Musgo, parou. Pip, o espírito do
relógio, pede ajuda. O jogador junta materiais, constrói máquinas e entrega peças em 6 etapas até o relógio
voltar a andar. Depois do final o jogo continua em modo livre.

## Ciclo de jogo

1. **Coletar à mão** (cortar árvores, quebrar pedras, minerar, colher, pescar).
2. **Criar** construções e peças na mochila.
3. **Automatizar**: brocas → esteiras → fornalhas → garras → montadoras → Relógio/Caixa de Envio.
4. **Entregar** os itens da etapa no Grande Relógio (à mão ou por esteira/garra) → moedas, presente e novas receitas.
5. **Expandir**: fazenda automática, energia, ponte para o leste (cristais), ruínas e chefe.

## Etapas do Grande Relógio

| # | Nome | Entregar | Moedas | Presente | Libera |
|---|---|---|---|---|---|
| 1 | Raízes Dormentes | 10 madeira, 10 pedra | 30 | 6 sementes de nabo | Esteira, Garra, Cata-vento, Broca, Lampião |
| 2 | Primeiras Brasas | 12 placa de cobre, 12 placa de ferro, 10 tábua | 80 | 6 sementes de trigo | Montadora, Divisor, Aspersor, Engrenagens, Fios |
| 3 | Dentes e Fios | 20 engrenagem, 30 fio, 12 nabo | 160 | 3 sem. abóbora, 3 sem. baga | Colhedora, Cozinha, Roda d'Água, Cabana Lenhadora, Circuitos, Liga |
| 4 | Mesa Farta | 20 circuito, 15 liga, 10 pão | 300 | 3 sopas | Lentes, Mecanismos, Reator, Chave das Ruínas |
| 5 | Luz de Cristal | 15 lente, 12 mecanismo, 10 geleia | 500 | 2 tortas | Núcleo de Cristal |
| 6 | O Coração do Vale | 10 núcleo, 10 torta, 1 Núcleo Antigo (do chefe) | 1000 | — | Final |

O campo `tier` das receitas indica a etapa mínima. Dados completos em `dados/etapas.json` e `dados/receitas.json`.

## Fábrica

| Construção | Função | Energia |
|---|---|---|
| Esteira | Move itens (1,7 tile/s); entrega direto na máquina à frente. Traçada arrastando o dedo. Curvas automáticas. | — |
| Garra | Pega o item de **trás** e solta na **frente**; filtro opcional por item. | — |
| Fornalha | Minério + combustível → placa/tijolo (3 s). Guarda até 10 de entrada, 10 de combustível, 20 de saída. | — |
| Baú | 240 itens. | — |
| Broca | Sobre minério; 1 item a cada 2,2 s; solta na direção da seta. | usa 4 |
| Montadora | Uma receita escolhida; aceita até 3× os insumos. | usa 6 |
| Cozinha | Como a montadora, para comidas. | usa 5 |
| Divisor | Reparte itens em rodízio entre frente, direita e esquerda. | — |
| Aspersor | Rega plantações em 3×3. | — |
| Colhedora | Colhe plantas maduras em 5×5; solta na direção da seta. | usa 5 |
| Cabana Lenhadora | Produz madeira (e às vezes fibra) conforme as árvores em 5×5 (máx. 5). | usa 4 |
| Lampião | Ilumina e afasta gosmas. | — |
| Cata-vento | Gera 12, raio 5. | gera |
| Roda d'Água | Gera 30, raio 6; precisa encostar na água. | gera |
| Reator de Cristal | Gera 120, raio 8; queima cristais (45 s cada) só quando há demanda acima da base. | gera |
| Caminho de Pedra | Piso decorativo; anda-se mais rápido. | — |

**Energia:** rede única do vale. Uma máquina só funciona se estiver dentro do raio de algum gerador.
Se a demanda passa da geração, **todas** ficam proporcionalmente mais lentas (`ratio = geração/demanda`).

**Fixas no mapa:** Grande Relógio (aceita entregas), Casa (dormir), Caixa de Envio (vende o que cair nela),
Banca da Tia Nonô (loja).

## Fazenda

- 4 plantações: nabo (primavera), trigo e baga-sol (verão), abóbora (outono). Tempos de 80 a 210 s.
- Só crescem em terra molhada: regador (A), chuva ou aspersor. Estação favorita ×1,5; inverno ×0,6.
- Depois de colhidas rebrotam sozinhas (não é preciso replantar).
- Cozinha: farinha, pão, sopa, geleia, torta, peixe grelhado. Comida cura corações.
- Pesca: de frente para a água, A para lançar, A de novo quando aparecer o "!".

## Tempo

- 1 dia = 8 minutos reais (1440 min de jogo, 3 min de jogo por segundo). Amanhece às 06:00; noite das 20:00 às 05:00.
- 4 dias por estação; 4 estações (terreno, árvores e paleta mudam). 28 % de chance de chuva/neve por manhã.
- Dormir na casa avança até a manhã, cura tudo e salva.

## Aventura e combate

- Corações (meio coração = 1 de vida; começa com 3 corações). Espada no botão B: combo de três toques (corte, contra-corte e giro em área, que causa +1 de dano).
- Criaturas: Gosma (2 PV), Gosma azul (5 PV), Morcego (1 PV), Sentinela de pedra (6 PV), **Guardião de Musgo** (chefe, 40 PV, fica furioso com metade da vida).
- Aparecem na floresta escura do oeste, além da ponte e à noite longe de casa. Zona segura perto do Relógio e de lampiões.
- Desmaiar: volta para casa, perde parte das moedas e 2 h de jogo.
- Ponte do leste: consertar com 20 tábuas + 10 placas de ferro → Bosque de Cristal.
- Ruínas ao norte: portão abre com a Chave das Ruínas; no fundo dorme o Guardião, que solta o Núcleo Antigo.
- 8 baús de tesouro escondidos (moedas, corações extras, espada melhor).

## NPCs

- **Pip** — espírito do relógio; explica o objetivo atual (tem "!" quando o objetivo muda).
- **Tia Nonô** — toupeira lojista: sementes, sopa e melhorias (coração extra, ferramentas, botas, lâmina).
- **Seu Bento** — sapo pescador: troca 3 peixes por um coração e sementes; dá dicas.

## Mundo (80×80 tiles, semente fixa 1337)

Centro: Relógio (39,39), Casa (34,35), Caixa de Envio (37,36), Banca (45,36), poço, placa.
Sul: pedreira com cobre, ferro, carvão e pedra. Sudoeste: lago e Seu Bento. Oeste: floresta escura.
Leste: rio com ponte quebrada e Bosque de Cristal. Norte: escadaria, portão e ruínas (platô elevado).
O mapa completo está em `dados/mapa.json`.

## Controles

| Ação | Celular | Computador |
|---|---|---|
| Andar | direcional virtual ou toque no chão (caminho automático) | WASD / setas |
| Agir (cortar, minerar, colher, regar, pescar, conversar, abrir) | botão A ou toque no alvo | Espaço |
| Espada | botão B (três toques seguidos terminam em giro) | K |
| Construir | toque no item da barra e depois no chão; esteiras: arrastar | clique |
| Girar / desmontar | botão Girar / X vermelho da barra | R |
| Mochila / zoom | botões no HUD; pinça para zoom | E |

## Interface

HUD: corações, moedas, energia (uso/geração), relógio com mostrador do céu, zoom, menu, caixa de missão
com contadores da etapa, barra do chefe, avisos. Barra inferior: mochila, modo desmontar e itens colocáveis.
Mochila com abas: Itens, Criar, Relógio, Mapa, Mais (opções, estatísticas, guia). Painel próprio por máquina.
