# Musgo & Engrenagens — instruções do projeto

## O que é
Jogo cozy 2,5D isométrico para celular em pé (9:16): fazenda + automação + aventura, com predominância de automação.
Protótipo de referência: `jogo/index.html` (jogo completo em um arquivo). Objetivo atual: porte para **Godot 4**.

## Stack
Godot 4 (estável) + GDScript · Aseprite + Aseprite Wizard · Dialogic 2 · Phantom Camera · LimboAI · GUT · jsfxr/ChipTone.
Desenvolvimento no Windows. Alvos: Android (principal), Windows e web.

## Documentos
- `docs/01_design_do_jogo.md` — regras e conteúdo
- `docs/02_arquitetura_do_prototipo.md` — como o protótipo funciona (fonte da verdade do comportamento)
- `docs/03_stack_godot.md` — stack, configuração e estrutura de pastas
- `docs/04_plano_de_porte.md` — marcos e critérios de aceite
- `docs/05_assets_e_direcao_de_arte.md` — arte e assets
- `dados/*.json`, `arte/` — dados e sprites exportados do protótipo

## Regras de trabalho
- Idioma: português (código e identificadores podem ficar em inglês; textos do jogo em pt-BR).
- Respostas objetivas. Ao terminar, dizer o que foi testado e o que **não** foi (ex.: não testado em aparelho real).
- Simulação da fábrica é dado puro em autoload, passo fixo de 30 Hz, separada das cenas. Não criar um nó por item de esteira.
- Dados do jogo ficam em `data/` (JSON/Resource), não espalhados no código.
- Toda regra de simulação nova ou portada ganha teste GUT.
- Pixel art: filtro Nearest, escala inteira, um único tamanho de pixel no jogo.
- Assets de terceiros: registrar autor, link e licença em `CREDITOS.md`.
- Não alterar `jogo/index.html`: ele é a referência congelada. Para conferir um comportamento, rode-o ou use `ferramentas/`.
- Commits pequenos com mensagens claras; não abrir pull request sem pedido explícito.

## Comandos úteis
- Protótipo: abrir `jogo/index.html` no navegador.
- Ferramentas do protótipo: `cd ferramentas && npm install && npx playwright install chromium && npm run testes`.
- Reexportar dados/arte do protótipo: `npm run exportar` (em `ferramentas/`).
