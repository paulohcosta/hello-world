# Musgo & Engrenagens — pacote de passagem de projeto

Este pacote contém tudo o que é preciso para continuar o projeto em outra pasta/repositório e em outra conversa:
o protótipo jogável final (HTML), a documentação do que existe, os dados e a arte exportados para reuso,
as ferramentas de teste/captura e a proposta de nova stack (Godot 4).

**Comece por aqui:**

1. Abra `jogo/index.html` no navegador para ver o estado atual do jogo (funciona offline, sem instalar nada).
2. Leia `docs/03_stack_godot.md` (stack sugerida) e `docs/04_plano_de_porte.md` (como migrar, em marcos).
3. Na nova conversa, cole o conteúdo de `PROMPT_NOVA_THREAD.md`.
4. Copie `CLAUDE.md` para a raiz do novo repositório: são as instruções permanentes do projeto para o assistente.

## Conteúdo

| Pasta/arquivo | O que é |
|---|---|
| `jogo/index.html` | **Protótipo final de hoje.** Jogo completo em um único arquivo (HTML + CSS + JS, sem bibliotecas). É também o código-fonte: não existe etapa de build. |
| `docs/01_design_do_jogo.md` | Design: conceito, ciclo de jogo, etapas, máquinas, receitas, fazenda, combate, mundo, controles. |
| `docs/02_arquitetura_do_prototipo.md` | Mapa do código do `index.html` (seções, funções, estruturas de dados, simulação, renderização, save). |
| `docs/03_stack_godot.md` | Stack sugerida (Godot 4 + GDScript + addons + ferramentas), instalação no Windows, estrutura de projeto. |
| `docs/04_plano_de_porte.md` | Plano de migração em marcos, equivalências JS → Godot, o que reaproveitar, testes de equivalência. |
| `docs/05_assets_e_direcao_de_arte.md` | Direção de arte atual, a decisão de perspectiva, fontes de assets prontos e cuidados de licença. |
| `docs/06_historico_e_licoes.md` | O que foi feito em cada rodada, bugs encontrados e lições que valem para o porte. |
| `dados/*.json` | Tabelas do jogo exportadas (itens, construções, receitas, etapas, plantações, loja, criaturas, mapa inicial…). |
| `arte/` | **667 PNGs** exportados da arte procedural (ícones, terreno, árvores, objetos, máquinas, personagens, criaturas, interface) + `indice.json` com tamanhos de quadro e âncoras. |
| `ferramentas/` | Scripts Node + Playwright: testes headless, capturas de tela e os exportadores de dados e arte. Ver `ferramentas/README.md`. |
| `capturas/` | Capturas de tela do estado final (título, HUD, painéis, estações, fábrica, combate). |
| `historico/` | `musgo.bundle` (histórico git completo do protótipo) e `git_log.txt`. |
| `PROMPT_NOVA_THREAD.md` | Texto pronto para iniciar a nova conversa. |
| `CLAUDE.md` | Instruções do projeto para o novo repositório. |

## Estado do protótipo (resumo honesto)

- Jogo completo e jogável do início ao fim: 6 etapas do Grande Relógio, 16 construções, 52 itens, 34 receitas,
  4 plantações, 4 estações, clima, dia/noite, 5 tipos de criatura (incluindo chefe), loja, 3 NPCs, save local.
- Toda a arte (pixel art) e todo o áudio (efeitos e música) são gerados por código em tempo de execução.
- Testado **apenas em Chromium headless** (viewports 390×844, 360×640 e desktop) com os scripts de `ferramentas/`.
  **Nunca foi testado em um celular real.** Animações foram avaliadas por quadros parados.
- Limites conhecidos estão em `docs/06_historico_e_licoes.md`.

## Sobre os "scripts que geraram o HTML"

O `index.html` foi escrito diretamente (edições incrementais ao longo de 6 rodadas). Não há gerador nem build:
o arquivo é a fonte. O que acompanha em `ferramentas/` são os scripts usados para **testar e capturar** o jogo
durante o desenvolvimento, mais dois exportadores novos (`exportar_dados.js`, `exportar_arte.js`) que extraem
do HTML os dados e a arte para reuso na nova stack. Os remendos pontuais aplicados durante as rodadas eram
comandos avulsos e não foram guardados; o resultado deles está no histórico git (`historico/musgo.bundle`).

## Como levar para um repositório novo (Windows)

```powershell
# 1) descompacte o zip e entre na pasta
cd musgo-engrenagens-handoff

# 2a) começar repositório novo só com o material
git init ; git add . ; git commit -m "Material de passagem do protótipo HTML"

# 2b) OU recuperar também o histórico do protótipo
git clone -b prototipo historico\musgo.bundle prototipo-html

# 3) (opcional) rodar as ferramentas — precisa de Node.js 18+
cd ferramentas
npm install
npx playwright install chromium
npm run testes
```
